# ec-core
 
前端EC服务依赖核心组件

## 功能

- JedisClientImp Redis客户端
- YamibuyConstant 公共常量
- YamibuyException 业务异常
- DynamicDataSourceRegister 多数据源注册

## 工具类

- DateUtil
- ExportUtils
- FixedThreadPoolUtil 线程池
- FullHalfWidthTransform
- HttpClientUtil Http客户端
- IPUtils
- ListUtils 集合
- NetworkUtil
- PDFExportUtils PDF导出
- RAMPageUtil 内存分页
- ResourceUtil
- RestTestUtil 单元测试
- SendMailUtil 邮件发送
- SpringfactoryUtils Spring实例工厂
- SSLClientUtil Https客户端
- StringUtils 字符串
- TokenUtil Token处理
- YamiDateUtil
- YamiPropertiesUtil
- YamiStringUtils
- YamiXMLUtil

## 扩展
1. 公共配置文件application.properties中添加配置节
central:
```
EMAIL_TEMPLATE_QUERY_PATH = http://{central-domain-name}/hub/common/template/email
```
ec:
```
EMAIL_TEMPLATE_QUERY_PATH = http://{ec-domain-name}/ec-common/template/email
```

2. thymeleaf模板解析器配置：ThymeleafTemplateResolverConfiguration
```java
@Bean
public StringResourceTemplateResolver stringResourceTemplateResolver() {
  // 参考 https://www.javadevjournal.com/spring-boot/spring-boot-thymeleaf/
  StringResourceTemplateResolver resolver = new StringResourceTemplateResolver();
  resolver.setTemplateMode(StandardTemplateModeHandlers.HTML5.getTemplateModeName());
  resolver.setCharacterEncoding("UTF-8");
  resolver.setOrder(0);  // this is important. This way spring //boot will listen to both places 0 and 1
  return resolver;
}
```
3. 新建模板解析器：StringResourceTemplateResolver
```java
public StringResourceTemplateResolver() {
  super();
  this.resourceResolver = new StringResourceResourceResolver();
  setOrder(2);
  super.setResourceResolver(this.resourceResolver);
}
```
4. 新建模板资源解析器：StringResourceResourceResolver
```java
@Override
public InputStream getResourceAsStream(TemplateProcessingParameters templateProcessingParameters,
    String resourceName) {
  Validate.notNull(resourceName, "String Resource cannot be null");
  Validate.notEmpty(resourceName, "String Resource cannot be empty");
  InputStream inputStream = null;
  try {
    String content = getResourceString(resourceName);
    inputStream = new ByteArrayInputStream(content.getBytes("UTF-8"));
  } catch (final Exception e) {
    log.warn("StringResourceResourceResolver cannot resolve resource: {}, error message is: {}", resourceName,
        e.getMessage());
  }

  return inputStream;
}

private String getResourceString(String resourceName) {
  String url = SpringfactoryUtils.getProperty(EMAIL_TEMPLATE_QUERY_PATH);
  Map<String, String> paramMap = Maps.newHashMap(KEY_NAME, resourceName);
  String response = ClientAccessUtil.accesssForEntity(url, paramMap, null, null, String.class,
      ClientAccessUtil.ACCESS_METHOD_GET);
  return response;
}
```
