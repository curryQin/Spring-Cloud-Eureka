package com.yamibuy.ec.core.aop;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.yamibuy.ec.core.annotation.NonConcurrent;
import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;

import lombok.val;
import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
@Order(3)
public class ConcurrentCheckAspect {

	@SuppressWarnings("rawtypes")
	@Autowired
	private RedisTemplate redisTemplate;

	@SuppressWarnings("unchecked")
	@Around("execution(public * com.yamibuy..rest..*.*(..))")
	public Object around(ProceedingJoinPoint point) throws Throwable {
		MethodSignature signature = (MethodSignature) point.getSignature();
		String className = signature.getDeclaringType().getName();
		Method method = signature.getMethod();
		String classNameWithMethod = className + "." + method.getName();

		// 并发校验
		val nonConcurrent = method.getAnnotation(NonConcurrent.class);
		if (null != nonConcurrent) {
			log.info("并发校验:{}", classNameWithMethod);
			Object[] obj = point.getArgs();
			String paramStr = JSON.toJSONString(obj);
			log.info("param:{}", paramStr);
			String key = classNameWithMethod + "." + paramStr;
			boolean lock = redisTemplate.opsForValue().setIfAbsent(key, true);
			log.info("是否取得锁：{}", lock);
			if (lock) {
				// 如果在执行任务的过程中，程序突然挂了，为了避免程序因为中断而造成一直加锁的情况产生，3分钟后，key值失效，自动释放锁
				redisTemplate.expire(key, 3, TimeUnit.MINUTES);
				val result = point.proceed();
				redisTemplate.delete(key);
				return result;
			} else {
				throw new YamibuyException(YamibuyMessageCode.REQUEST_PROCESSING.getCode());
			}
		} else {
			return point.proceed();
		}
	}
}
