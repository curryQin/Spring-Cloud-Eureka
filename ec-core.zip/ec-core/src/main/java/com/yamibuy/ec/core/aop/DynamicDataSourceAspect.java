package com.yamibuy.ec.core.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.yamibuy.ec.core.annotation.TargetDataSource;
import com.yamibuy.ec.core.common.DynamicDataSourceContextHolder;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Order(-1) // 保证该AOP在@Transactional之前执行
@Component
@Slf4j
public class DynamicDataSourceAspect {
	@Before("@annotation(ds)")
	public void changeDataSource(JoinPoint point, TargetDataSource ds) {
		String name = ds.name();
		if (!DynamicDataSourceContextHolder.containsDataSource(name)) {
			log.error("数据源[{}]不存在，使用默认数据源 > {}", name, point.getSignature());
		} else {
			log.debug("Use DataSource : {} > {}", name, point.getSignature());
			DynamicDataSourceContextHolder.setDataSourceType(name);
		}
	}

	@After("@annotation(ds)")
	public void restoreDataSource(JoinPoint point, TargetDataSource ds) {
		String name = ds.name();
		log.debug("Revert DataSource : {} > {}", name, point.getSignature());
		DynamicDataSourceContextHolder.clearDataSourceType();
	}
}
