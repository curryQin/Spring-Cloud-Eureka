package com.yamibuy.ec.core.aop;

import java.sql.SQLException;

import org.apache.http.NoHttpResponseException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;

import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.yamibuy.ec.core.common.ErrorMessageEnum;
import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.entity.ErrorResponse;
import com.yamibuy.ec.core.util.FixedThreadPoolUtil;
import com.yamibuy.ec.core.util.SendMailUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
@Order(0)
public class ExceptionAspect {

	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private Environment env;

	@Around("execution(public * com.yamibuy..rest..*.*(..))")
	public Object around(ProceedingJoinPoint point) throws Throwable {
		Object responseObject = null;
		try {
			responseObject = point.proceed();
		} catch (YamibuyException ye) {
			ErrorResponse<Object> response = ye.getResponse();
			log.warn("YamibuyException Error messageId: {}, desc : {}", response.getMessageId(),
					response.getEnError());
			Object body = response.getBody();
			if (body instanceof Exception) {
				response.setBody(null);
			}
			return response;
		} catch (Exception ex) {
			return systemExceptionHandler(ex, point);
		}
		return responseObject;
	}

	private ErrorResponse<Object> systemExceptionHandler(Exception ex, ProceedingJoinPoint point) {
		String exceptionRefKey = "eKey:" + System.currentTimeMillis();
		log.error("System Exception Aspect - SystemException - Exception Ref Key : {} ", exceptionRefKey);
		log.error("Exception: {}", ex.getClass());
		log.error(ex.getLocalizedMessage(), ex);
		String alertInfo = "Please contact yamibuy IT with the eKey. Thanks!";
		// 异步发送异常信息邮件
		FixedThreadPoolUtil
				.doExecutor(() -> SendMailUtil.sendExceptionMail(env, templateEngine, ex, point, exceptionRefKey));
		if (ex instanceof HystrixRuntimeException) {
			return ErrorResponse.sendSystemException(ErrorMessageEnum.CONNECT_TIME_OUT.getErrorMessage(),
					exceptionRefKey, alertInfo);
		} else if (ex instanceof NoHttpResponseException) {
			return ErrorResponse.sendSystemException(ErrorMessageEnum.HTTP_CONNECT_EXCEPTION.getErrorMessage(),
					exceptionRefKey, alertInfo);
		} else if (ex instanceof SQLException) {
			return ErrorResponse.sendSystemException(ErrorMessageEnum.SQL_EXCEPTION.getErrorMessage(), exceptionRefKey,
					alertInfo);
		} else {
			return ErrorResponse.sendSystemException(ErrorMessageEnum.SYSTEMERROR.getErrorMessage(), exceptionRefKey,
					alertInfo);
		}
	}
}
