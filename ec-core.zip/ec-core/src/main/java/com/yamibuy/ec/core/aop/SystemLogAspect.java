package com.yamibuy.ec.core.aop;

import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.yamibuy.ec.core.common.YamibuyConstant;
import com.yamibuy.ec.core.entity.LoginRequestParam;
import com.yamibuy.ec.core.entity.RegisterRequestParam;
import com.yamibuy.ec.core.entity.ServerRequestLogEntity;
import com.yamibuy.ec.core.entity.Token;
import com.yamibuy.ec.core.util.IPUtils;
import com.yamibuy.ec.core.util.TokenUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
@Order(1)
public class SystemLogAspect {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Value("${spring.application.name}")
	private String applicationName;

	/**
	 * 超时时间
	 */
	private Long PRODUCER_SEND_TIMEOUT = 100L;

	@Around("execution(public * com.yamibuy..rest..*.*(..))")
	public Object around(ProceedingJoinPoint point) throws Throwable {
		long time = System.currentTimeMillis();
		String className = point.getTarget().getClass().getName();
		String methodName = point.getSignature().getName();
		String methodFullName = className + "." + methodName;
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		String requestUrl = request.getRequestURI();
//		String tokenStr = request.getHeader(YamibuyConstant.KEY_TOKEN);
		log.info("Request IP : {}",IPUtils.getIpAddress(request));
		Object[] obj = point.getArgs();
		if (null == obj || obj.length < 1) {
			log.info("Request URL: {}, Request Method: {}", requestUrl, methodFullName);
		} else {
			try {
				Object[] cloneObj =obj.clone();
				if("com.yamibuy.ec.customer.rest.CustomerRest.login".equals(methodFullName)) {
					Object param1 = cloneObj[0];
					String param1String = JSON.toJSONString(param1);
					LoginRequestParam loginRequest =  JSON.parseObject(param1String, LoginRequestParam.class);
					loginRequest.setPwd("******");
					
					log.info("Request URL: {}, Request Method: {}, Request body : {}", requestUrl, methodFullName, JSON.toJSONString(loginRequest) + JSON.toJSONString(cloneObj[1]));
				}else if ("com.yamibuy.ec.customer.rest.CustomerRest.registerUser".equals(methodFullName)) {
					Object param1 = cloneObj[0];
					String param1String = JSON.toJSONString(param1);
					RegisterRequestParam registerRequest =  JSON.parseObject(param1String, RegisterRequestParam.class);
					registerRequest.setPwd("******");
					log.info("Request URL: {}, Request Method: {}, Request body : {}", requestUrl, methodFullName, JSON.toJSONString(registerRequest) + JSON.toJSONString(cloneObj[2]));
				}
				else {
					log.info("Request URL: {}, Request Method: {}, Request body : {}", requestUrl, methodFullName, JSON.toJSONString(cloneObj));
				}
			} catch (Exception e) {
				log.info("Request URL: {}, Request Method: {} ,Request body final : {}", requestUrl, methodFullName,obj);
			}
			
			

//			if (tokenStr != null && !tokenStr.isEmpty() && !"{token}".equals(tokenStr)) {
//				Token token = TokenUtil.convert(tokenStr);
//				if (token !=null && token.getIsLogin() == 1) {
//					log.info("Request Method: {}, Request user_id : {}", methodFullName, token.getData());
//				}
//			}
		}

		// kafaka 发送统计信息
		// ServerRequestLogEntity serverRequestLogEntity = new ServerRequestLogEntity();
		// serverRequestLogEntity.setApplication_name(applicationName);
		// serverRequestLogEntity.setToken(tokenStr);
		// serverRequestLogEntity.setParameter(obj);
		// serverRequestLogEntity.setMethod(methodFullName);
		// serverRequestLogEntity.setUser_agent(request.getHeader("User-Agent"));
		// serverRequestLogEntity.setRequest_url(requestUrl);
		// serverRequestLogEntity.setReferer(request.getHeader("Referer"));
		// serverRequestLogEntity.setDate(request.getHeader("Date")); // 可能拿不到
		// serverRequestLogEntity.setServer_time(System.currentTimeMillis());

		// Future<?> future = FixedThreadPoolUtil.doExecutor(new KafkaAsynSender(serverRequestLogEntity));
		// try {
		// 	future.get(PRODUCER_SEND_TIMEOUT, TimeUnit.MILLISECONDS);
		// } catch (InterruptedException e) {
		// 	future.cancel(true);
		// } catch (ExecutionException e) {
		// 	future.cancel(true);
		// } catch (TimeoutException e) {
		// 	future.cancel(true);
		// }

		Object responseObject = point.proceed();
		log.debug("Request URL: {}, Response: {}", requestUrl, responseObject);
		log.info("Request URL: {}, Spend Time: {}ms", requestUrl, System.currentTimeMillis() - time);
		return responseObject;
	}

	class KafkaAsynSender implements Callable<ListenableFuture> {

		private ServerRequestLogEntity serverRequestLogEntity;

		public KafkaAsynSender(ServerRequestLogEntity serverRequestLogEntity) {
			this.serverRequestLogEntity = serverRequestLogEntity;
		}

		@Override
		public ListenableFuture call() throws Exception {
			ListenableFuture send = kafkaTemplate.send(applicationName,
					JSON.toJSONString(serverRequestLogEntity, 1, SerializerFeature.SortField,
							SerializerFeature.WriteMapNullValue, SerializerFeature.DisableCircularReferenceDetect));
			return send;
		}

	}
}
