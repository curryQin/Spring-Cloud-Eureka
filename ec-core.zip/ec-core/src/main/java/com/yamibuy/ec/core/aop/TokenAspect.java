package com.yamibuy.ec.core.aop;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.yamibuy.ec.core.annotation.NeedLogin;
import com.yamibuy.ec.core.common.YamibuyConstant;
import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;
import com.yamibuy.ec.core.entity.Token;
import com.yamibuy.ec.core.util.StringUtils;
import com.yamibuy.ec.core.util.TokenUtil;
import com.yamibuy.ec.core.util.YamiDateUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Aspect
@Slf4j
@Order(4)
public class TokenAspect {

	private static final String PLEASE_LOGIN = "Need Login";
	private static final String TOKEN_IS_EXPIRED_PLEASE_RE_LOGIN = "Token is expired, Please ReLogin";
	private static final String TOKEN_IS_INVALID_PLEASE_LOGIN = "Token is invalid , Please Login";

	/**
	 * 前台Token登录校验切面 范围 com.yamibuy.*.rest, 例如 com.yamibuy.sns.rest,
	 * com.yamibuy.mkt.rest
	 * 
	 * @param point
	 * @throws Exception
	 */
	@Before("execution(public * com.yamibuy..rest..*.*(..))")
	public void checkToken(JoinPoint point) throws Exception {
		try {
			MethodSignature signature = (MethodSignature) point.getSignature();
			Method method = signature.getMethod();
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			
			boolean isNeedLogin = method.isAnnotationPresent(NeedLogin.class);
			if (!isNeedLogin) {
				return;
			}
			String tokenStr = request.getHeader(YamibuyConstant.KEY_TOKEN);
			
			// 1 TOKEN INVALID 无效
			if (tokenStr == null || tokenStr.isEmpty() || "{token}".equals(tokenStr)) {
				throw new YamibuyException(TOKEN_IS_INVALID_PLEASE_LOGIN, YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
			}
			Token token = TokenUtil.convert(tokenStr);
			
			// 2 登陆验证
			if (token == null ||  token.getIsLogin() != YamibuyConstant.IS_LOGIN) {
				throw new YamibuyException(PLEASE_LOGIN, YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
			}
			// 3 过期验证
//			if (token.getExp() < YamiDateUtil.get_LA_Second()) {
//				throw new YamibuyException(TOKEN_IS_EXPIRED_PLEASE_RE_LOGIN, YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
//			}
			
			// 4  校验密码是否正确
			String salt = token.getSalt();
			checkAuth(token, salt, token.getData());
		} catch (YamibuyException e) {
			log.debug(e.getLocalizedMessage(), e);
			throw e;
		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
			throw new YamibuyException(TOKEN_IS_INVALID_PLEASE_LOGIN, YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
		}

	}

	private void checkAuth(Token token, String salt, String uid) throws Exception {
		String auth = StringUtils.EncoderByMd5(salt, uid, YamibuyConstant.ENCTIMES);
		if (!token.getAuth().equals(auth)) {
			throw new YamibuyException(TOKEN_IS_INVALID_PLEASE_LOGIN, YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
		}
	}
}
