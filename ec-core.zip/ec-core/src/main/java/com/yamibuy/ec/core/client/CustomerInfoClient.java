package com.yamibuy.ec.core.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.yamibuy.ec.core.entity.BaseResponse;
import com.yamibuy.ec.core.entity.User;

@FeignClient(name = "${feign.ec-customer.name:}", url = "${feign.ec-customer.url:}")
public interface CustomerInfoClient {

	@RequestMapping(value = "/info/simple", method = RequestMethod.GET)
	BaseResponse<User> querySimpleInfoByToken(@RequestHeader("token") String token);
	
	@RequestMapping(value = "/info/simple/{user_id}", method = RequestMethod.GET)
	BaseResponse<User> querySimpleInfoById(@PathVariable("user_id") Integer user_id);
	
}
