package com.yamibuy.ec.core.common;

import java.util.List;

import com.yamibuy.ec.core.entity.BaseRequestPage;

public interface BaseDao<T> {
	Integer insert(T t);

	Integer update(T t);

	Integer delete(Object id);

	Integer queryCount(T t);

	List<T> queryList(BaseRequestPage page);

	T queryById(Object id);
}
