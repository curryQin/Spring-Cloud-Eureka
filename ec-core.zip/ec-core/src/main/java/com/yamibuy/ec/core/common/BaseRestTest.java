package com.yamibuy.ec.core.common;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

/**
 * spring boot controller 单元测试基类
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
public abstract class BaseRestTest {

	protected MockMvc mockMvc;

	@Autowired
	WebApplicationContext webApplicationContext;

	protected static final String HEADER_TOKEN_NAME = "token";
	protected static final String HEADER_TOKEN_VALUE = "charles.kou";
	protected static final String RESPONSE_SUCCESS_KEY = "messageId";

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
}
