package com.yamibuy.ec.core.common;

import java.util.List;

import com.yamibuy.ec.core.entity.BaseRequestPage;

public abstract class BaseService<T> {

	public BaseDao<T> getDao() {
		return null;
	}

	public Integer insert(T t) {
		return getDao().insert(t);
	}

	public void update(T t) {
		getDao().update(t);
	}

	public void delete(Object... ids) {
		if (ids == null || ids.length < 1) {
			return;
		}
		for (Object id : ids) {
			getDao().delete(id);
		}
	}

	public Integer queryCount(T t) {
		return getDao().queryCount(t);
	}

	public List<T> queryList(BaseRequestPage page) {
		return getDao().queryList(page);
	}

	public T queryById(Object id) {
		return getDao().queryById(id);
	}

}
