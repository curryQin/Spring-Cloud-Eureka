package com.yamibuy.ec.core.common;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

public class CustomIntegerDeserialize extends JsonDeserializer<Integer> {

	@Override
	public Integer deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		boolean isBoolean = p.getCurrentToken().isBoolean();
		if (isBoolean) {
			return p.getBooleanValue() == Boolean.TRUE.booleanValue() ? 1 : 0;
		}
		return p.getIntValue();
	}

}
