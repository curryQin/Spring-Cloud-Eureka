package com.yamibuy.ec.core.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.alibaba.druid.pool.DruidDataSource;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DatasourceLogRunner implements CommandLineRunner {

	@Autowired(required = false)
	private DruidDataSource dataSource;

	@Override
	public void run(String... args) throws Exception {
		if (null != dataSource) {
			log.info("默认数据源: {}", dataSource.getUrl());
		}
	}
}
