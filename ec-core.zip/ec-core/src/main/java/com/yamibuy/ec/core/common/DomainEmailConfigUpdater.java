package com.yamibuy.ec.core.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.yamibuy.ec.core.dao.DomainEmailConfigDao;
import com.yamibuy.ec.core.entity.DomainEmailConfig;
import com.yamibuy.ec.core.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DomainEmailConfigUpdater {
	private static final Map<String, DomainEmailConfig> map = new HashMap<>();
	
	@Autowired
	private DomainEmailConfigDao domainEmailConfigDao;
	
	@Value("${spring.application.name}")
	private String applicationName;

	@Value("${exception.email.to:}")
	private String emailTo;

	@Value("${exception.email.cc:}")
	private String emailCC;

	/**
	 * 同步异常邮件配置信息
	 */
	public void sync() {
		log.info("同步异常邮件配置信息");
		if (StringUtils.isNotEmpty(emailTo)) {
			log.info("domain {} 配置  exception.email.to = {}", applicationName, emailTo);
			DomainEmailConfig domainEmailConfig = new DomainEmailConfig();
			domainEmailConfig.setDomain(applicationName);
			domainEmailConfig.setEmail_to(emailTo);
			domainEmailConfig.setEmail_cc(emailCC);
			map.put(applicationName, domainEmailConfig);
		} else {
			log.error("domain {} 未配置  exception.email.to 属性, 读取数据库配置");
			List<DomainEmailConfig> list = domainEmailConfigDao.queryAll();
			for (DomainEmailConfig domainEmailConfig : list) {
				map.put(domainEmailConfig.getDomain(), domainEmailConfig);
			}
		}
	}

	public DomainEmailConfig getConfigByName(String applicationName) {
		DomainEmailConfig domainEmailConfig = map.get(applicationName);
		if (null == domainEmailConfig) {
			sync();
			domainEmailConfig = map.get(applicationName);
			if (null == domainEmailConfig) {
				log.error("domain {} 未配置异常邮件接收人，请在domain_mail_config表中进行配置, 或在配置文件中添加属性  exception.email.to",
						applicationName);
			}
		}
		return domainEmailConfig;
	}

}
