package com.yamibuy.ec.core.common;

import java.util.ArrayList;
import java.util.List;

public class DynamicDataSourceContextHolder {
	private static final List<String> dataSourceIds = new ArrayList<>();
	private static final ThreadLocal<String> contextHolder = new ThreadLocal<>();

	private DynamicDataSourceContextHolder() {
	}

	public static void setDataSourceType(String dataSourceType) {
		contextHolder.set(dataSourceType);
	}

	public static String getDataSourceType() {
		return contextHolder.get();
	}

	public static void clearDataSourceType() {
		contextHolder.remove();
	}

	/**
	 * 判断指定DataSrouce当前是否存在
	 *
	 * @param dataSourceId
	 * @return boolean
	 */
	public static boolean containsDataSource(String dataSourceId) {
		return getDataSourceIds().contains(dataSourceId);
	}

	public static List<String> getDataSourceIds() {
		return dataSourceIds;
	}
}
