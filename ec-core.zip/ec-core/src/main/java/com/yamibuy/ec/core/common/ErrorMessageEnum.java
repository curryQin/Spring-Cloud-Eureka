package com.yamibuy.ec.core.common;

import lombok.Getter;

public enum ErrorMessageEnum {

	CONNECT_TIME_OUT("90026",
			"RuntimeException that is thrown when a HystrixCommand fails and does not have a fallback.",
			"运行时抛出异常，熔断没有找到fallback方法"), 
	HTTP_CONNECT_EXCEPTION("90027",
					"Signals that the target server failed to respond with a valid HTTP response",
					"目标服务器未能返回有效的HTTP响应"), 
	SQL_EXCEPTION("90028", "SQL have some wrong",
							"SQL语句有误"), 
	SYSTEMERROR("99999", "System Error", "系统异常");

	@Getter
	private String messageId;
	@Getter
	private String enError;
	@Getter
	private String zhError;

	private ErrorMessageEnum(String messageId, String enError, String zhError) {
		this.messageId = messageId;
		this.enError = enError;
		this.zhError = zhError;
	}

	public String[] getErrorMessage() {
		String[] ErrorMessages = new String[3];
		ErrorMessages[0] = messageId;
		ErrorMessages[1] = enError;
		ErrorMessages[2] = zhError;
		return ErrorMessages;
	}
}
