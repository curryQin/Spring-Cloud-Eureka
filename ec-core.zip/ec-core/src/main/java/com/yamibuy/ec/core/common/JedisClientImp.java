package com.yamibuy.ec.core.common;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Transaction;
import redis.clients.jedis.Tuple;
import redis.clients.jedis.params.sortedset.ZIncrByParams;

@Component
@Slf4j
@ConditionalOnProperty("spring.redis.host")
public class JedisClientImp extends Jedis {

	@Resource
	private JedisPool jedisPool;

	public void setJedisPool(JedisPool jedisPool) {
		this.jedisPool = jedisPool;
	}

	public JedisPool getJedisPool() {
		return jedisPool;
	}

	
	

	@Override
	public Long exists(String... keys) {
		Long exists = null;
		try (Jedis jedis = jedisPool.getResource()) {
			exists = jedis.exists(keys);
		} catch (Exception e) {
			log.error("jedis exists failed", e);
		}
		return exists;
	}

	@Override
	public Long del(String... keys) {
		Long del = null;
		try (Jedis jedis = jedisPool.getResource()) {
			del = jedis.del(keys);
		} catch (Exception e) {
			log.error("jedis del failed", e);
		}
		return del;
	}

	@Override
	public String getSet(String key, String value) {
		String getSet = null;
		try (Jedis jedis = jedisPool.getResource()) {
			getSet = jedis.getSet(key,value);
		} catch (Exception e) {
			log.error("jedis getSet failed", e);
		}
		return getSet;
	}

	@Override
	public List<String> mget(String... keys) {
		List<String> mget = null;
		try (Jedis jedis = jedisPool.getResource()) {
			mget = jedis.mget(keys);
		} catch (Exception e) {
			log.error("jedis mget failed", e);
		}
		return mget;
	}

	@Override
	public Long setnx(String key, String value) {
		Long setnx = null;
		try (Jedis jedis = jedisPool.getResource()) {
			setnx = jedis.setnx(key,value);
		} catch (Exception e) {
			log.error("jedis setnx failed", e);
		}
		return setnx;
	}

	@Override
	public String mset(String... keysvalues) {
		String mset = null;
		try (Jedis jedis = jedisPool.getResource()) {
			mset = jedis.mset(keysvalues);
		} catch (Exception e) {
			log.error("jedis getSet failed", e);
		}
		return mset;
	}

	@Override
	public List<String> hmget(String key, String... fields) {
		List<String> hmget = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hmget = jedis.hmget(key,fields);
		} catch (Exception e) {
			log.error("jedis hmget failed", e);
		}
		return hmget;
	}

	@Override
	public Map<String, String> hgetAll(String key) {
		Map<String, String> hgetAll = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hgetAll = jedis.hgetAll(key);
		} catch (Exception e) {
			log.error("jedis hgetAll failed", e);
		}
		return hgetAll;
	}

	@Override
	public Long rpush(String key, String... strings) {
		Long rpush = null;
		try (Jedis jedis = jedisPool.getResource()) {
			rpush = jedis.rpush(key,strings);
		} catch (Exception e) {
			log.error("jedis rpush failed", e);
		}
		return rpush;
	}

	@Override
	public Long lpush(String key, String... strings) {
		Long lpush = null;
		try (Jedis jedis = jedisPool.getResource()) {
			lpush = jedis.lpush(key,strings);
		} catch (Exception e) {
			log.error("jedis lpush failed", e);
		}
		return lpush;
	}

	@Override
	public String lpop(String key) {
		String lpop = null;
		try (Jedis jedis = jedisPool.getResource()) {
			lpop = jedis.lpop(key);
		} catch (Exception e) {
			log.error("jedis lpop failed", e);
		}
		return lpop;
	}

	@Override
	public String rpop(String key) {
		String rpop = null;
		try (Jedis jedis = jedisPool.getResource()) {
			rpop = jedis.rpop(key);
		} catch (Exception e) {
			log.error("jedis rpop failed", e);
		}
		return rpop;
	}

	@Override
	public String getrange(String key, long startOffset, long endOffset) {
		String getrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			getrange = jedis.getrange(key,startOffset,endOffset);
		} catch (Exception e) {
			log.error("jedis getrange failed", e);
		}
		return getrange;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@Override
	public Long del(String key) {
		Long del = null;
		try (Jedis jedis = jedisPool.getResource()) {
			del = jedis.del(key);
		} catch (Exception e) {
			log.error("jedis del failed", e);
		}
		return del;
	}

	@Override
	public Boolean exists(String key) {
		Boolean boolean1 = null;
		try (Jedis jedis = jedisPool.getResource()) {
			boolean1 = jedis.exists(key);
		} catch (Exception e) {
			log.error("jedis exists failed", e);
		}
		return boolean1;
	}

	@Override
	public Boolean hexists(String key, String field) {
		Boolean result = null;
		try (Jedis jedis = jedisPool.getResource()) {
			result = jedis.hexists(key, field);
		} catch (Exception e) {
			log.error("jedis hexists failed", e);
		}
		return result;
	}

	@Override
	public Set<String> hkeys(String key) {
		Set<String> hkeys = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hkeys = jedis.hkeys(key);
		} catch (Exception e) {
			log.error("jedis hkeys failed", e);
		}
		return hkeys;
	}

	@Override
	public List<String> hvals(String key) {
		List<String> hvals = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hvals = jedis.hvals(key);
		} catch (Exception e) {
			log.error("jedis hvals failed", e);
		}
		return hvals;
	}

	public Boolean hexists(Object key, Object field) {
		return hexists(String.valueOf(key), String.valueOf(field));
	}

	@Override
	public Long hdel(String key, String... fields) {
		Long hdel = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hdel = jedis.hdel(key, fields);
		} catch (Exception e) {
			log.error("jedis hdel failed", e);
		}
		return hdel;
	}
	
	@Override
	public String hmset(String key, Map<String,String> hash) {
		String hmset = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hmset = jedis.hmset(key, hash);
		} catch (Exception e) {
			log.error("jedis hmset failed", e);
		}
		return hmset;
	}
	
	

	@Override
	public Long expire(String key, int seconds) {
		Long expire = null;
		try (Jedis jedis = jedisPool.getResource()) {
			expire = jedis.expire(key, seconds);
		} catch (Exception e) {
			log.error("jedis expire failed", e);
		}
		return expire;
	}

	@Override
	public String get(String key) {
		String value = null;
		try (Jedis jedis = jedisPool.getResource()) {
			value = jedis.get(key);
		} catch (Exception e) {
			log.error("jedis get failed", e);
		}
		return value;
	}

	@Override
	public byte[] get(byte[] key) {
		byte[] value = null;
		try (Jedis jedis = jedisPool.getResource()) {
			value = jedis.get(key);
		} catch (Exception e) {
			log.error("jedis get failed", e);
		}
		return value;
	}

	@Override
	public String hget(String key, String field) {
		String hget = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hget = jedis.hget(key, field);
		} catch (Exception e) {
			log.error("jedis hget failed", e);
		}
		return hget;
	}

	public String hget(Object key, Object field) {
		return hget(String.valueOf(key), String.valueOf(field));
	}

	@Override
	public Long hset(String key, String field, String value) {
		Long hset = null;
		try (Jedis jedis = jedisPool.getResource()) {
			hset = jedis.hset(key, field, value);
		} catch (Exception e) {
			log.error("jedis hset failed", e);
		}
		return hset;
	}

	public Long hset(String key, Object field, Object value) {
		String jsonString = JSON.toJSONString(value);
		String fieldStr = String.valueOf(field);
		return hset(key, fieldStr, jsonString);
	}

	@Override
	public Long incr(String key) {
		Long result = -1L;
		try (Jedis jedis = jedisPool.getResource()) {
			result = jedis.incr(key);
		} catch (Exception e) {
			log.error("jedis incr fialed", e);
		}
		return result;
	}

	@Override
	public String set(String key, String value) {
		String set = null;
		try (Jedis jedis = jedisPool.getResource()) {
			set = jedis.set(key, value);
		} catch (Exception e) {
			log.error("jedis set failed", e);
		}
		return set;
	}

	@Override
	public Long zadd(String key, double score, String member) {
		Long zadd = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zadd = jedis.zadd(key, score, member);

		} catch (Exception e) {
			log.error("jedis add failed", e);
		}
		return zadd;
	}

	@Override
	public Double zincrby(String key, double score, String member, ZIncrByParams params) {
		Double zincrby = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zincrby = jedis.zincrby(key, score, member, params);
		} catch (Exception e) {
			log.error("jedis zincrby failed", e);
		}
		return zincrby;
	}

	@Override
	public Long zrem(String key, String... member) {
		Long zrem = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zrem = jedis.zrem(key, member);
		} catch (Exception e) {
			log.error("jedis zrem failed", e);
		}

		return zrem;
	}

	@Override
	public Long zremrangeByScore(String key, double start, double end) {
		Long zremrangeByScore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zremrangeByScore = jedis.zremrangeByScore(key, start, end);
		} catch (Exception e) {
			log.error("zremrangeByScore failed", e);
		}
		return zremrangeByScore;
	}

	@Override
	public Set<Tuple> zrangeWithScores(String key, long start, long end) {
		Set<Tuple> tupleSet = null;
		try (Jedis jedis = jedisPool.getResource()) {
			tupleSet = jedis.zrangeWithScores(key, start, end);
		} catch (Exception e) {
			log.error("zrangeWithScores failed", e);
		}
		return tupleSet;
	}

	@Override
	public Double zscore(String key, String member) {
		Double zscore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zscore = jedis.zscore(key, member);
		} catch (Exception e) {
			log.error("JedisClient zscore failed", e);
		}
		return zscore;
	}

	@Override
	public Set<String> zrange(String key, long start, long end) {
		Set<String> zrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zrange = jedis.zrange(key, start, end);
		} catch (Exception e) {
			log.error("JedisClient zrange failed", e);
		}
		return zrange;
	}

	@Override
	public Set<String> zrevrange(String key, long start, long end) {
		Set<String> zrevrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zrevrange = jedis.zrevrange(key, start, end);
		} catch (Exception e) {
			log.error("JedisClient zrevrange failed", e);
		}
		return zrevrange;
	}

	@Override
	public Long zcount(String key, double min, double max) {
		Long zcount = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zcount = jedis.zcount(key, min, max);
		} catch (Exception e) {
			log.error("JedisClient zcount failed", e);
		}
		return zcount;
	}

	@Override
	public Long zcard(String key) {
		Long zcard = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zcard = jedis.zcard(key);
		} catch (Exception e) {
			log.error("JedisClient zcard failed", e);
		}
		return zcard;
	}

	@Override
	public Set<String> zrangeByScore(String key, double min, double max) {
		Set<String> zrangeByScore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zrangeByScore = jedis.zrangeByScore(key, min, max);
		} catch (Exception e) {
			log.error("JedisClient zrangeByScore failed", e);
		}
		return zrangeByScore;
	}

	@Override
	public Set<String> keys(String pattern) {
		Set<String> keys = null;
		try (Jedis jedis = jedisPool.getResource()) {
			keys = jedis.keys(pattern);
		} catch (Exception e) {
			log.error("JedisClient keys failed", e);
		}
		return keys;
	}

	@Override
	public Boolean setbit(String key, long offset, boolean value) {
		Boolean setbit = Boolean.FALSE;
		try (Jedis jedis = jedisPool.getResource()) {
			setbit = jedis.setbit(key, offset, value);
		} catch (Exception e) {
			log.error("JedisClient setbit failed", e);
		}
		return setbit;
	}

	@Override
	public Boolean setbit(String key, long offset, String value) {
		Boolean setbit = Boolean.FALSE;
		try (Jedis jedis = jedisPool.getResource()) {
			setbit = jedis.setbit(key, offset, value);
		} catch (Exception e) {
			log.error("JedisClient setbit failed", e);
		}
		return setbit;
	}

	@Override
	public Boolean getbit(String key, long offset) {
		Boolean getbit = Boolean.FALSE;
		try (Jedis jedis = jedisPool.getResource()) {
			getbit = jedis.getbit(key, offset);
		} catch (Exception e) {
			log.error("JedisClient getbit failed", e);
		}
		return getbit;
	}

	@Override
	public String ping() {
		try (Jedis jedis = jedisPool.getResource()) {
			return jedis.ping();
		}
	}
	
	
	@Override
	public Long lrem(String key, long count, String value) {
		Long lrem = null;
		try (Jedis jedis = jedisPool.getResource()) {
			lrem = jedis.lrem(key, count, value);
		} catch (Exception e) {
			log.error("jedis lrem failed", e);
		}
		return lrem;
	}

	@Override
	public Long llen(String key) {
		Long llen = null;
		try (Jedis jedis = jedisPool.getResource()) {
			llen = jedis.llen(key);
		} catch (Exception e) {
			log.error("jedis llen failed", e);
		}
		return llen;
	}
	
	@Override
	public List<String> lrange(String key, long start, long end) {
		List<String> lrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			lrange = jedis.lrange(key, start, end);
		} catch (Exception e) {
			log.error("jedis lrange failed", e);
		}
		return lrange;
	}
	
	@Override
	public Long incrBy(String key,long size) {
		Long result = -1L;
		try (Jedis jedis = jedisPool.getResource()) {
			result = jedis.incrBy(key, size);
		} catch (Exception e) {
			log.error("jedis incrBy fialed", e);
		}
		return result;
	}
	


	@Override
	public Long zremrangeByRank(String key, long start, long end) {
		Long zremrangeByRank = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zremrangeByRank = jedis.zremrangeByRank(key, start, end);
		} catch (Exception e) {
			log.error("jedis zremrangeByRank failed", e);
		}
		return zremrangeByRank;
	}

	@Override
	public Long zunionstore(String dstkey, String... sets) {
		Long zunionstore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			zunionstore = jedis.zunionstore(dstkey, sets);
		} catch (Exception e) {
			log.error("jedis zunionstore failed", e);
		}
		return zunionstore;
	}
	

	
	
	
	// ========= have db version =========================


	public Long zremrangeByRank(Integer db, String key, long start, long end) {
		Long zremrangeByRank = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zremrangeByRank = jedis.zremrangeByRank(key, start, end);
		} catch (Exception e) {
			log.error("jedis zremrangeByRank failed", e);
		}
		return zremrangeByRank;
	}

	public Long zunionstore(Integer db, String dstkey, String... sets) {
		Long zunionstore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zunionstore = jedis.zunionstore(dstkey, sets);
		} catch (Exception e) {
			log.error("jedis zunionstore failed", e);
		}
		return zunionstore;
	}

	 public String rename(Integer db,String oldkey, String newkey) {
	  String res = "";
	  try (Jedis jedis = jedisPool.getResource()) {
	   jedis.select(db);
	   res = jedis.rename(oldkey,newkey);
	  } catch (Exception e) {
	   log.error("jedis hgetAll failed", e);
	  }
	  return res;
	 }

	
	public Long incrBy(Integer db,String key,long size) {
		Long result = -1L;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			result = jedis.incrBy(key, size);
		} catch (Exception e) {
			log.error("jedis incrBy fialed", e);
		}
		return result;
	}
	
	public Long del(Integer db,String key) {
		Long del = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			del = jedis.del(key);
		} catch (Exception e) {
			log.error("jedis del failed", e);
		}
		return del;
	}

	
	public Boolean exists(Integer db,String key) {
		Boolean boolean1 = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			boolean1 = jedis.exists(key);
		} catch (Exception e) {
			log.error("jedis exists failed", e);
		}
		return boolean1;
	}

	
	public Boolean hexists(Integer db,String key, String field) {
		Boolean result = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			result = jedis.hexists(key, field);
		} catch (Exception e) {
			log.error("jedis hexists failed", e);
		}
		return result;
	}

	
	public Set<String> hkeys(Integer db,String key) {
		Set<String> hkeys = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hkeys = jedis.hkeys(key);
		} catch (Exception e) {
			log.error("jedis hkeys failed", e);
		}
		return hkeys;
	}

	
	public List<String> hvals(Integer db,String key) {
		List<String> hvals = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hvals = jedis.hvals(key);
		} catch (Exception e) {
			log.error("jedis hvals failed", e);
		}
		return hvals;
	}

	public Boolean hexists(Integer db,Object key, Object field) {
		return hexists(db,String.valueOf(key), String.valueOf(field));
	}

	
	public Long hdel(Integer db,String key, String... fields) {
		Long hdel = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hdel = jedis.hdel(key, fields);
		} catch (Exception e) {
			log.error("jedis hdel failed", e);
		}
		return hdel;
	}

	
	public Long expire(Integer db,String key, int seconds) {
		Long expire = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			expire = jedis.expire(key, seconds);
		} catch (Exception e) {
			log.error("jedis expire failed", e);
		}
		return expire;
	}

	
	public String get(Integer db,String key) {
		String value = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			value = jedis.get(key);
		} catch (Exception e) {
			log.error("jedis get failed", e);
		}
		return value;
	}

	
	public byte[] get(Integer db,byte[] key) {
		byte[] value = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			value = jedis.get(key);
		} catch (Exception e) {
			log.error("jedis get failed", e);
		}
		return value;
	}

	
	public String hget(Integer db,String key, String field) {
		String hget = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hget = jedis.hget(key, field);
		} catch (Exception e) {
			log.error("jedis hget failed", e);
		}
		return hget;
	}

	public String hget(Integer db,Object key, Object field) {
		return hget(db,String.valueOf(key), String.valueOf(field));
	}

	
	public Long hset(Integer db,String key, String field, String value) {
		Long hset = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hset = jedis.hset(key, field, value);
		} catch (Exception e) {
			log.error("jedis hset failed", e);
		}
		return hset;
	}

	public Long hset(Integer db,String key, Object field, Object value) {
		String jsonString = JSON.toJSONString(value);
		String fieldStr = String.valueOf(field);
		return hset(db,key, fieldStr, jsonString);
	}

	
	public Long incr(Integer db,String key) {
		Long result = -1L;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			result = jedis.incr(key);
		} catch (Exception e) {
			log.error("jedis incr fialed", e);
		}
		return result;
	}
	


	
	public String set(Integer db,String key, String value) {
		String set = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			set = jedis.set(key, value);
		} catch (Exception e) {
			log.error("jedis set failed", e);
		}
		return set;
	}

	
	public Long zadd(Integer db,String key, double score, String member) {
		Long zadd = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zadd = jedis.zadd(key, score, member);

		} catch (Exception e) {
			log.error("jedis add failed", e);
		}
		return zadd;
	}

	
	public Double zincrby(Integer db,String key, double score, String member, ZIncrByParams params) {
		Double zincrby = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zincrby = jedis.zincrby(key, score, member, params);
		} catch (Exception e) {
			log.error("jedis zincrby failed", e);
		}
		return zincrby;
	}

	
	public Long zrem(Integer db,String key, String... member) {
		Long zrem = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zrem = jedis.zrem(key, member);
		} catch (Exception e) {
			log.error("jedis zrem failed", e);
		}

		return zrem;
	}

	
	public Long zremrangeByScore(Integer db,String key, double start, double end) {
		Long zremrangeByScore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zremrangeByScore = jedis.zremrangeByScore(key, start, end);
		} catch (Exception e) {
			log.error("zremrangeByScore failed", e);
		}
		return zremrangeByScore;
	}

	
	public Set<Tuple> zrangeWithScores(Integer db,String key, long start, long end) {
		Set<Tuple> tupleSet = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			tupleSet = jedis.zrangeWithScores(key, start, end);
		} catch (Exception e) {
			log.error("zrangeWithScores failed", e);
		}
		return tupleSet;
	}

	
	public Double zscore(Integer db,String key, String member) {
		Double zscore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zscore = jedis.zscore(key, member);
		} catch (Exception e) {
			log.error("JedisClient zscore failed", e);
		}
		return zscore;
	}

	
	public Set<String> zrange(Integer db,String key, long start, long end) {
		Set<String> zrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zrange = jedis.zrange(key, start, end);
		} catch (Exception e) {
			log.error("JedisClient zrange failed", e);
		}
		return zrange;
	}

	
	public Set<String> zrevrange(Integer db,String key, long start, long end) {
		Set<String> zrevrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zrevrange = jedis.zrevrange(key, start, end);
		} catch (Exception e) {
			log.error("JedisClient zrevrange failed", e);
		}
		return zrevrange;
	}

	
	public Long zcount(Integer db,String key, double min, double max) {
		Long zcount = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zcount = jedis.zcount(key, min, max);
		} catch (Exception e) {
			log.error("JedisClient zcount failed", e);
		}
		return zcount;
	}

	
	public Long zcard(Integer db,String key) {
		Long zcard = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zcard = jedis.zcard(key);
		} catch (Exception e) {
			log.error("JedisClient zcard failed", e);
		}
		return zcard;
	}

	
	public Set<String> zrangeByScore(Integer db, String key, double min, double max) {
		Set<String> zrangeByScore = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			zrangeByScore = jedis.zrangeByScore(key, min, max);
		} catch (Exception e) {
			log.error("JedisClient zrangeByScore failed", e);
		}
		return zrangeByScore;
	}

	
	public Set<String> keys(Integer db,String pattern) {
		Set<String> keys = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			keys = jedis.keys(pattern);
		} catch (Exception e) {
			log.error("JedisClient keys failed", e);
		}
		return keys;
	}

	
	public Boolean setbit(Integer db, String key, long offset, boolean value) {
		Boolean setbit = Boolean.FALSE;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			setbit = jedis.setbit(key, offset, value);
		} catch (Exception e) {
			log.error("JedisClient setbit failed", e);
		}
		return setbit;
	}

	
	public Boolean setbit(Integer db,String key, long offset, String value) {
		Boolean setbit = Boolean.FALSE;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			setbit = jedis.setbit(key, offset, value);
		} catch (Exception e) {
			log.error("JedisClient setbit failed", e);
		}
		return setbit;
	}

	
	public Boolean getbit(Integer db,String key, long offset) {
		Boolean getbit = Boolean.FALSE;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			getbit = jedis.getbit(key, offset);
		} catch (Exception e) {
			log.error("JedisClient getbit failed", e);
		}
		return getbit;
	}
	
	
	public String hmset(Integer db,String key, Map<String,String> hash) {
		String hmset = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hmset = jedis.hmset(key, hash);
		} catch (Exception e) {
			log.error("jedis hmset failed", e);
		}
		return hmset;
	}
	
	
	public Long exists(Integer db,String... keys) {
		Long exists = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			exists = jedis.exists(keys);
		} catch (Exception e) {
			log.error("jedis exists failed", e);
		}
		return exists;
	}

	
	public Long del(Integer db,String... keys) {
		Long del = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			del = jedis.del(keys);
		} catch (Exception e) {
			log.error("jedis del failed", e);
		}
		return del;
	}

	
	public String getSet(Integer db,String key, String value) {
		String getSet = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			getSet = jedis.getSet(key,value);
		} catch (Exception e) {
			log.error("jedis getSet failed", e);
		}
		return getSet;
	}

	
	public List<String> mget(Integer db,String... keys) {
		List<String> mget = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			mget = jedis.mget(keys);
		} catch (Exception e) {
			log.error("jedis mget failed", e);
		}
		return mget;
	}

	
	public Long setnx(Integer db,String key, String value) {
		Long setnx = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			setnx = jedis.setnx(key,value);
		} catch (Exception e) {
			log.error("jedis setnx failed", e);
		}
		return setnx;
	}

	
	public String mset(Integer db,String... keysvalues) {
		String mset = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			mset = jedis.mset(keysvalues);
		} catch (Exception e) {
			log.error("jedis getSet failed", e);
		}
		return mset;
	}

	
	public List<String> hmget(Integer db,String key, String... fields) {
		List<String> hmget = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hmget = jedis.hmget(key,fields);
		} catch (Exception e) {
			log.error("jedis hmget failed", e);
		}
		return hmget;
	}


	@Override
	public String rename(String oldkey, String newkey) {
		String res = "";
		try (Jedis jedis = jedisPool.getResource()) {
			res = jedis.rename(oldkey,newkey);
		} catch (Exception e) {
			log.error("jedis hgetAll failed", e);
		}
		return res;
	}

	public Map<String, String> hgetAll(Integer db, String key) {
		Map<String, String> hgetAll = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			hgetAll = jedis.hgetAll(key);
		} catch (Exception e) {
			log.error("jedis hgetAll failed", e);
		}
		return hgetAll;
	}

	
	public Long rpush(Integer db,String key, String... strings) {
		Long rpush = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			rpush = jedis.rpush(key,strings);
		} catch (Exception e) {
			log.error("jedis rpush failed", e);
		}
		return rpush;
	}

	
	public Long lpush(Integer db,String key, String... strings) {
		Long lpush = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			lpush = jedis.lpush(key,strings);
		} catch (Exception e) {
			log.error("jedis lpush failed", e);
		}
		return lpush;
	}

	
	public String lpop(Integer db,String key) {
		String lpop = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			lpop = jedis.lpop(key);
		} catch (Exception e) {
			log.error("jedis lpop failed", e);
		}
		return lpop;
	}

	
	public String rpop(Integer db,String key) {
		String rpop = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			rpop = jedis.rpop(key);
		} catch (Exception e) {
			log.error("jedis rpop failed", e);
		}
		return rpop;
	}

	
	public String getrange(Integer db,String key, long startOffset, long endOffset) {
		String getrange = null;
		try (Jedis jedis = jedisPool.getResource()) {
			jedis.select(db);
			getrange = jedis.getrange(key,startOffset,endOffset);
		} catch (Exception e) {
			log.error("jedis getrange failed", e);
		}
		return getrange;
	}

	/***
	 * 事务扣除队列库存
	 * @param keys
	 * @return
	 */
	public List<Object> transacRpopCommand(List<String> keys) {
		List<Object> list = null;
		try (Jedis jedis = jedisPool.getResource();
			 Transaction transaction = jedis.multi()
			) {
			for (String str : keys){
				transaction.rpop(str);
			}
			list = transaction.exec();
		} catch (Exception e) {
			log.error("jedis getrange failed", e);
		}
		if(transaction != null){
			transaction.discard();
		}
		return list;
	}

	public void batchLpush(List<String> keys,String value){
		try (Jedis jedis = jedisPool.getResource()) {
			Pipeline pipeline = jedis.pipelined();
			for(String key : keys){
				pipeline.lpush(key,value);
			}
			pipeline.sync();
		} catch (Exception e) {
			log.error("jedis batchLpush failed", e);
		}
	}
}
