package com.yamibuy.ec.core.common;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;

import org.thymeleaf.TemplateProcessingParameters;
import org.thymeleaf.resourceresolver.IResourceResolver;
import org.thymeleaf.util.Validate;

import com.google.common.collect.Maps;
import com.yamibuy.ec.core.util.ClientAccessUtil;
import com.yamibuy.ec.core.util.SpringfactoryUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StringResourceResourceResolver implements IResourceResolver {

	public static final String NAME = "STRING-RESOURCE";
	public static final String KEY_NAME = "key";
	public static final String EMAIL_TEMPLATE_QUERY_PATH = "EMAIL_TEMPLATE_QUERY_PATH";

	public StringResourceResourceResolver() {
		super();
	}

	@Override
	public String getName() {
		return NAME;
	}

	@Override
	public InputStream getResourceAsStream(TemplateProcessingParameters templateProcessingParameters,
			String resourceName) {
		Validate.notNull(resourceName, "String Resource cannot be null");
		Validate.notEmpty(resourceName, "String Resource cannot be empty");
		InputStream inputStream = null;
		try {
			String content = getResourceString(resourceName);
			inputStream = new ByteArrayInputStream(content.getBytes("UTF-8"));
		} catch (final Exception e) {
			log.warn("StringResourceResourceResolver cannot resolve resource: {}, error message is: {}", resourceName,
					e.getMessage());
		}

		return inputStream;
	}

	private String getResourceString(String resourceName) {
		String url = SpringfactoryUtils.getProperty(EMAIL_TEMPLATE_QUERY_PATH);
		Map<String, String> paramMap = Maps.newHashMap();
		paramMap.put(KEY_NAME, resourceName);
		String response = ClientAccessUtil.accesssForEntity(url, paramMap, null, null, String.class,
				ClientAccessUtil.ACCESS_METHOD_GET);
		return response;
	}

}
