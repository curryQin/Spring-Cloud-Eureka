package com.yamibuy.ec.core.common;

import org.springframework.stereotype.Component;
import org.thymeleaf.templateresolver.TemplateResolver;

@Component
public class StringResourceTemplateResolver extends TemplateResolver {

	private final StringResourceResourceResolver resourceResolver;

	public StringResourceTemplateResolver() {
		super();
		this.resourceResolver = new StringResourceResourceResolver();
		super.setResourceResolver(this.resourceResolver);
	}
}
