package com.yamibuy.ec.core.common;

import java.math.BigDecimal;

public final class YamibuyConstant {
	public static final String STRING_DEFAULT = "";
	public static final int INT_DEFAULT = 0;
	public static final int INT_ZERO = 0;
	public static final BigDecimal DECIMAL_DEFAULT = new BigDecimal(0);
	public static final BigDecimal BIGDECIMAL_ZERO = new BigDecimal(0);

	public static final Integer IS_LOGIN = 1;
	public static final Integer IS_NOT_LOGIN = 0;

	public static final Integer SELLER_DEFAULT = 0;

	public static final String KEY_TOKEN = "token";

	public static final Integer PAGE_SIZE_DEFAULT = 10;
	public static final String ORDER_DESC = "desc";
	public static final String ORDER_ASC = "asc";

	public static final String LANGUAGE_CHINA = "zh_CN";
	public static final String LANGUAGE_US = "en_US";

	public static final int ENCTIMES = 2; // The times of encode md5

	public static final String RESPONSE_SUCCESS = "success";
}
