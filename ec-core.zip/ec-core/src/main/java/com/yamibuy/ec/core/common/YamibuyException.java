package com.yamibuy.ec.core.common;

import com.yamibuy.ec.core.entity.ErrorResponse;

import lombok.Getter;

public class YamibuyException extends RuntimeException {

	private static final long serialVersionUID = 4786241555414600753L;

	@Getter
	private final ErrorResponse<Object> response;

	public YamibuyException(String messageId) {
		this.response = ErrorResponse.sendException(messageId);
	}

	public <T> YamibuyException(T body, String messageId) {
		this.response = ErrorResponse.sendException(messageId, body);
	}

	public <T> YamibuyException(T body, String messageId, String... messageParameter) {
		this.response = ErrorResponse.sendException(messageId, body, messageParameter);
	}

	public YamibuyException(Exception exception, String messageid) {
		if (exception instanceof YamibuyException) {
			YamibuyException ex = (YamibuyException) exception;
			this.response = ex.getResponse();
		} else {
			this.response = ErrorResponse.sendException(messageid, exception);
		}
	}
}
