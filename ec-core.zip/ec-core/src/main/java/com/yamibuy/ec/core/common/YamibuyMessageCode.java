package com.yamibuy.ec.core.common;

public enum YamibuyMessageCode {//success code
    SUCCESS("10000"),
    //No Handle System error code
    SYSTEMERROR("99999"),
    //System error is 9 + error number 0001
    ERROR_REQUESTMESSAGE("90001"),
	ERROR_JSON2STRING("90002"),
    WRONGVALUE_BIGDECIMAL("90003"),
    MANDATORY_INUSER("90004"),
    MANDATORY_EDIT_USER("90005"),
    
    TOKEN_EXPIRED("90006"),
    TOKEN_IS_INVALID("90008"),
    FAILED_GET_USERINFO("90007"),
    
    NO_PERMISSION("90009"),
    NO_LOGIN("90010"),
    
    IMAGE_NOT_LEGITIMATE("90011"),
    REDIS_DOWN("90012"),
    EXPORTEXCEL_LIMIT("90013"),
    FAILED_SEND_NOTICE("90014"),
    
    FAILED_LOGIN("90015"),
    FAILED_CHANGE_PASSWORD("90016"),
    INVALID_PASSWORD("90017"),
    NOTMATCH_PASSWORD("90018"),
    INCORRECT_PASSWORD("90019"),
    USER_NOTEXIST("90020"),
    
    EMAILTOKEN_ERROR("90021"),
    EMAILTOKEN_EXPIRED("90022"),
    REQUEST_PROCESSING("90023"),
    REQUEST_PARAMETER_NOT_COMPLETE("90024"), 
    
    MESSAGE_ENCRIPT_FAILED("90025"),
  	;

    private String emsg;

    private YamibuyMessageCode(String emsg) {
        this.emsg = emsg;
    }

    public String getCode() {
        return emsg;
    }
}
