package com.yamibuy.ec.core.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yamibuy.ec.core.util.StringUtils;

import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@Configuration
@EnableCaching
@Slf4j
@ConditionalOnProperty("spring.redis.host")
public class RedisCacheConfiguration extends CachingConfigurerSupport {

	@Value("${spring.redis.host}")
	private String host;

	@Value("${spring.redis.port}")
	private int port;

	@Value("${spring.redis.timeout}")
	private int timeout;

	@Value("${spring.redis.pool.max-idle:8}")
	private int maxIdle;
	
	@Value("${spring.redis.pool.min-idle:0}")
	private int minIdle;
	
	@Value("${spring.redis.pool.max-total:8}")
	private int maxTotal;

	@Value("${spring.redis.pool.max-wait:-1}")
	private long maxWaitMillis;

	@Value("${spring.redis.password:}")
	private String password;
	
	@Value("${spring.redis.database}")
	private int database;
	
	@Bean(name = "jedisPool")
	public JedisPool redisPoolFactory() {
		log.info("JedisPool注入成功, host:{},port:{},timeout:{},maxIdle:{},maxWaitMillis:{},database:{},", host, port, timeout,maxIdle,maxWaitMillis,database);
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		jedisPoolConfig.setMaxIdle(maxIdle);
		jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
		jedisPoolConfig.setMaxTotal(maxTotal);
		jedisPoolConfig.setMinIdle(minIdle);
		password = StringUtils.isNullOrEmpty(password) ? null : password;
		return new JedisPool(jedisPoolConfig, host, port, timeout, password, database);
	}

	/**
	 * key = className
	 * @return
	 */
	@Bean
	public KeyGenerator classNameKeyGenerator() {
		return (target, method, params) -> {
			StringBuilder sb = new StringBuilder();
			sb.append(target.getClass().getName());
			return sb.toString();
		};
	}
	
	/**
	 * key = className.params
	 * @return
	 */
	@Bean
	public KeyGenerator classWithParamKeyGenerator() {
		return (target, method, params) -> {
			StringBuilder sb = new StringBuilder();
			sb.append(target.getClass().getName());
			sb.append(".");
			for (Object obj : params) {
				sb.append(obj.toString());
			}
			return sb.toString();
		};
	}
	
	/**
	 * key = className.mathodName.params
	 * @return
	 */
	@Bean
	public KeyGenerator wiselyKeyGenerator() {
		return (target, method, params) -> {
			StringBuilder sb = new StringBuilder();
			sb.append(target.getClass().getName());
			sb.append(method.getName());
			for (Object obj : params) {
				sb.append(obj.toString());
			}
			return sb.toString();
		};
	}

	@SuppressWarnings("rawtypes")
	@Bean
	public CacheManager cacheManager(RedisTemplate redisTemplate) {
		RedisCacheManager redisCacheManager = new RedisCacheManager(redisTemplate);
		// 设置默认缓存失效时间 3600s=1h
		redisCacheManager.setDefaultExpiration(3600);
		return redisCacheManager;
	}

	@Bean
	public RedisTemplate<String, String> redisTemplate(RedisConnectionFactory factory) {
		StringRedisTemplate template = new StringRedisTemplate(factory);
		Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer<>(Object.class);
		ObjectMapper om = new ObjectMapper();
		om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
		om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		jackson2JsonRedisSerializer.setObjectMapper(om);
		template.setValueSerializer(jackson2JsonRedisSerializer);
		template.afterPropertiesSet();
		return template;
	}

}