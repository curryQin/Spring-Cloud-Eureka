package com.yamibuy.ec.core.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.templatemode.StandardTemplateModeHandlers;

import com.yamibuy.ec.core.common.StringResourceTemplateResolver;

@Configuration
public class ThymeleafTemplateResolverConfiguration {

	@Bean
	public StringResourceTemplateResolver stringResourceTemplateResolver() {
		StringResourceTemplateResolver resolver = new StringResourceTemplateResolver();
		resolver.setTemplateMode(StandardTemplateModeHandlers.HTML5.getTemplateModeName());
		resolver.setCharacterEncoding("UTF-8");
		resolver.setCacheable(true);
		resolver.setCacheTTLMs(10 * 60 * 1000L); // 10min
		resolver.setOrder(0);
		return resolver;
	}

}
