package com.yamibuy.ec.core.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.yamibuy.ec.core.entity.DomainEmailConfig;

@Mapper
public interface DomainEmailConfigDao {

	@Select("SELECT `rec_id`, `plat`, `domain`, `email_to`, `email_cc`, `in_dtm`, `in_user`, `edit_dtm`, `edit_user` "
			+ "FROM Yamibuy_Central.domain_mail_config")
	List<DomainEmailConfig> queryAll();
}