package com.yamibuy.ec.core.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.yamibuy.ec.core.entity.Sendmail;

@Mapper
public interface SendMailDao {

	/**
	 * @param sendmail
	 * @return
	 */
	@Insert("INSERT INTO Yamibuy_Master.ym_sendmail (order_id, name, email, cc, subject, count, send_time, content) "
			+ "VALUES (#{orderId}, #{name}, #{email}, #{cc}, #{subject}, #{count}, #{send_time}, #{content})")
	Integer insert(Sendmail sendmail);

}