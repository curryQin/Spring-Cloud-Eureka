package com.yamibuy.ec.core.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseRequestPage {
	// Search Key
	private String keyword;

	// How many record show at one page
	private Integer pageSize;

	// Start record when turn page
	private Integer startColumn;

	// order by which column
	private Order order;

	// Only a mark for pager
	private Integer draw;

	// 页码
	private int page;

	public BaseRequestPage(String keyword, int pageSize, int startColumn, Order order, int draw) {
		super();
		this.keyword = keyword;
		this.pageSize = pageSize;
		this.startColumn = startColumn;
		this.order = order;
		this.draw = draw;
	}

	public void setPageSize(Integer pageSize) {
		int defaultPageSize = 10;
		this.pageSize = null != pageSize ? pageSize : defaultPageSize;
	}

	public void setStartColumn(Integer startColumn) {
		int defaultStartColumn = 0;
		this.startColumn = null != startColumn ? startColumn : defaultStartColumn;
	}
}
