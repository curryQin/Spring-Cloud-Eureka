package com.yamibuy.ec.core.entity;

import com.yamibuy.ec.core.common.YamibuyConstant;
import com.yamibuy.ec.core.common.YamibuyMessageCode;

import lombok.Getter;
import lombok.Setter;

public class BaseResponse<T> {

	public static final BaseResponse<String> SUCCESS = responseSuccess();

	@Getter
	@Setter
	private String messageId = YamibuyMessageCode.SUCCESS.getCode();

	@Getter
	@Setter
	private String success = "true";

	@Getter
	@Setter
	private T body;

	public static <T> BaseResponse<T> send(T object) {
		BaseResponse<T> response = new BaseResponse<>();
		response.setBody(object);
		return response;
	}

	public static BaseResponse<String> responseSuccess() {
		BaseResponse<String> response = new BaseResponse<>();
		response.setBody(YamibuyConstant.RESPONSE_SUCCESS);
		return response;
	}
}
