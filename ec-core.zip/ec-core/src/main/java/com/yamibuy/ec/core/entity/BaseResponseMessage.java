package com.yamibuy.ec.core.entity;

import java.util.Arrays;
import java.util.List;

import com.yamibuy.ec.core.util.StringUtils;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BaseResponseMessage {
	private String messageId;
	private List<String> messageParameter;
	private Object body;

	public BaseResponseMessage(String messageId, Object body) {
		this.messageId = messageId;
		this.body = body;
	}

	public BaseResponseMessage(String messageId, Object body, String... messageParameters) {
		this.messageId = messageId;
		this.messageParameter = Arrays.asList(messageParameters);
		this.body = body;
	}

	public BaseResponseMessage(BaseResponseMessage baseResponseMessage) {
		if (!StringUtils.isEmpty(baseResponseMessage.getMessageId())) {
			this.messageId = baseResponseMessage.getMessageId();
		}
		if (!StringUtils.isEmpty(baseResponseMessage.getBody())) {
			this.body = baseResponseMessage.getBody();
		}
		if (!StringUtils.isEmpty(baseResponseMessage.getMessageParameter())) {
			this.messageParameter = baseResponseMessage.getMessageParameter();
		}
	}
}
