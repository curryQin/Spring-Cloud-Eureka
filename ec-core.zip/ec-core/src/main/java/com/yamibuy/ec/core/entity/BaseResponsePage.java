package com.yamibuy.ec.core.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BaseResponsePage {
	// Provide FE all records count number at table
	private Long recordsTotal;

	// Provide FE Filter records count number at table
	private Long recordsFiltered;

	// Only a mark for pager , very time need +1
	private Integer draw;

	// Data List
	private List<?> data;

	/**
	 * 
	 * @param recordsTotal
	 *            不参与分页,仅供前台显示
	 * @param recordsFiltered
	 *            分页用,记录总数
	 * @param draw
	 * @param data
	 */
	public BaseResponsePage(Integer recordsTotal, Integer recordsFiltered, Integer draw, List<?> data) {
		super();
		this.recordsTotal = Long.valueOf(String.valueOf(recordsTotal));
		this.recordsFiltered = Long.valueOf(String.valueOf(recordsFiltered));
		this.draw = draw;
		this.data = data;
	}
}
