package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class DataobjectMappingConfig {
	private Integer rec_id;
	private String dataobject_key;
	private Integer start_time;
	private String ref_type;
	private String ref_value;
	private Long in_dtm;
	private String in_user;
}
