package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class DataobjectQueryResult<T> {
	
	private Integer time;
	
	private T now;
	
	private T next;

}
