package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class DomainEmailConfig {
	private int rec_id;
	private String system;
	private String domain;
	private String email_to;
	private String email_cc;
	private Long in_dtm;
	private String in_user;
	private Long edit_dtm;
	private String edit_user;
}
