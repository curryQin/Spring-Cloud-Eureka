package com.yamibuy.ec.core.entity;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import com.yamibuy.ec.core.common.ErrorMessageEnum;
import com.yamibuy.ec.core.util.ResourceUtil;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorResponse<T> extends BaseResponse<T> {
	private List<String> messageParameter;
	private String zhError;
	private String enError;

	public void setMessageParameter(List<String> messageParameter) {
		this.messageParameter = messageParameter;
	}

	public void setMessageParameter(String... messageParameter) {
		this.messageParameter = Arrays.asList(messageParameter);
	}

	public static <T> ErrorResponse<T> sendException(String messageId) {
		ErrorResponse<T> response = new ErrorResponse<>();
		response.setMessageId(messageId);
		String zhError = ResourceUtil.getMessage(messageId, "resource", Locale.CHINA);
		response.setZhError(zhError);

		String enError = ResourceUtil.getMessage(messageId, "resource", Locale.US);
		response.setEnError(enError);

		response.setSuccess("false");
		return response;
	}

	public static <T> ErrorResponse<T> sendException(String messageId, T body) {
		ErrorResponse<T> response = sendException(messageId);
		response.setBody(body);
		return response;
	}

	public static <T> ErrorResponse<T> sendException(String messageId, T body, List<String> messageParameter) {
		ErrorResponse<T> response = sendException(messageId, body);
		response.setMessageParameter(messageParameter);
		return response;
	}

	public static <T> ErrorResponse<T> sendException(String messageId, T body, String... messageParameter) {
		ErrorResponse<T> response = sendException(messageId, body);
		response.setMessageParameter(messageParameter);
		return response;
	}
	
	public static <T> ErrorResponse<T> sendSystemException(ErrorMessageEnum errorMessage, String... messageParameter) {
		ErrorResponse<T> response = new ErrorResponse<>();
		response.setMessageId(errorMessage.getMessageId());
		response.setEnError(errorMessage.getEnError());
		response.setZhError(errorMessage.getZhError());
		response.setMessageParameter(messageParameter);
		
		response.setSuccess("false");
		return response;
	}
	
	public static <T> ErrorResponse<T> sendSystemException(String [] errorMessage, String... messageParameter) {
        ErrorResponse<T> response = new ErrorResponse<>();
        response.setMessageId(errorMessage[0]);
        response.setEnError(errorMessage[1]);
        response.setZhError(errorMessage[2]);
        response.setMessageParameter(messageParameter);
        response.setSuccess("false");
        return response;
    }
}
