package com.yamibuy.ec.core.entity;

import java.util.List;

import lombok.Data;

@Data
public class EventTrackEmailBody {

	private String event_name;
	
	private List<EventTrackEmailBodyParam> event_parameters;
}
