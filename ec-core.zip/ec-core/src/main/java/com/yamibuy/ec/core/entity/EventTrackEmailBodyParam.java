package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class EventTrackEmailBodyParam {

	private String name;
	
	private String value;
}
