package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class EventTrackEmailEntity {

	private EventTrackEmailHeader header;
	
	private EventTrackEmailBody body;
	
}
