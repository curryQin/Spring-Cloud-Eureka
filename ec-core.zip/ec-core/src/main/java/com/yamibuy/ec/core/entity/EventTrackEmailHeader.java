package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class EventTrackEmailHeader {

	private String token;
	
}
