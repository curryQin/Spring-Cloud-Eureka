package com.yamibuy.ec.core.entity;

import lombok.Data;

/**
 * @author www.yamibuy.com
 * @desc :
 * @date 2018/12/5
 * <b>版权所有：</b>版权所有(C) 2018，www.yamibuy.com<br>
 */
@Data
public class LoginRequestParam {

    private String token;
    private String email;
    private String pwd;

}
