package com.yamibuy.ec.core.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {

	// order base on which column
	private String orderColumn;

	// order base on desc or asc
	private String orderRule;
}
