package com.yamibuy.ec.core.entity;

import lombok.Data;

/**
 * @author www.yamibuy.com
 * @desc : 登录请求参数
 * @date 2018/11/29
 * <b>版权所有：</b>版权所有(C) 2018，www.yamibuy.com<br>
 */
@Data
public class RegisterRequestParam {

    private String token;

    private String email;

    private String pwd;

    private String invite_code;

    private String source;

    private Integer email_sub_flag;

    private String lang;

}
