package com.yamibuy.ec.core.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class Sendmail implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	private Integer orderId;

	private String name;

	private String email;

	private String cc;

	private String subject;

	private Short count = Short.valueOf("0");

	private Long send_time;

	private String content;
}
