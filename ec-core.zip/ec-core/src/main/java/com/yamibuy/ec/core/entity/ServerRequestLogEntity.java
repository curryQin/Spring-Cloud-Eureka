package com.yamibuy.ec.core.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class ServerRequestLogEntity implements Serializable {

	/**
	 * @Fields serialVersionUID : TODO
	 */
	private static final long serialVersionUID = 6936641794926574268L;
	private String token;
	private String user_agent;
	private String request_url;
	private Object parameter;
	private String referer;
	private String application_name;
	private String method;
	private String date;
	private Long server_time;
}
