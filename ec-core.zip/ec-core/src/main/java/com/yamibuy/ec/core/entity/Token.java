package com.yamibuy.ec.core.entity;

import lombok.Data;

@Data
public class Token {

	private long exp;

	private String data;

	private String auth;

	private String salt;

	private int isLogin;

}
