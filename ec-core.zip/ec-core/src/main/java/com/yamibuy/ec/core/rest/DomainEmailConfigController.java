package com.yamibuy.ec.core.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yamibuy.ec.core.common.DomainEmailConfigUpdater;
import com.yamibuy.ec.core.entity.BaseResponse;

@RestController
public class DomainEmailConfigController {

	@Autowired
	private DomainEmailConfigUpdater domainEmailConfigUpdater;

	@GetMapping("/domainconfig/refresh")
	public Object refresh() {
		domainEmailConfigUpdater.sync();
		return BaseResponse.SUCCESS;
	}

}
