package com.yamibuy.ec.core.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yamibuy.ec.core.dao.SendMailDao;
import com.yamibuy.ec.core.entity.Sendmail;

@Service
public class SendmailService {

	@Autowired
	private SendMailDao sendmailDao;

	public Integer insert(Sendmail sendmail) {
		return sendmailDao.insert(sendmail);
	}

}
