
package com.yamibuy.ec.core.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class ClientAccessUtil {

	public static final String ACCESS_METHOD_GET = "GET";

	public static final String ACCESS_METHOD_POST = "POST";

	public static final String ACCESS_METHOD_PUT = "PUT";

	public static final String ACCESS_METHOD_DELETE = "DELETE";

	private ClientAccessUtil() {
		super();
	}

	public static <T> T accesssForEntity(String url, Map<String, String> paramMap, Map<String, String> headerMap,
			String body, Class<T> clazz, String access_method) {
		T result = null;
		try {
			log.debug("ClientAccessUtil accesssForEntity url : {}, method : {}, header:{} , param : {} , body : {} ",
					url, access_method, JSON.toJSONString(headerMap), JSON.toJSONString(paramMap), body);
			String response = null;
			if (ACCESS_METHOD_GET.equalsIgnoreCase(access_method)) {
				response = SSLClientUtil.doGet(url, headerMap, paramMap);
			} else if (ACCESS_METHOD_POST.equalsIgnoreCase(access_method)) {
				response = SSLClientUtil.doPost(url, body, headerMap);
			} else if (ACCESS_METHOD_PUT.equalsIgnoreCase(access_method)) {
				response = SSLClientUtil.doPut(url, body, headerMap);
			} else if (ACCESS_METHOD_DELETE.equalsIgnoreCase(access_method)) {
				response = SSLClientUtil.doDelete(url, headerMap, paramMap);
			}
			log.debug("ClientAccessUtil accesssForEntity response : {}", response);
			result = parseEntityResult(clazz, response);
		} catch (Exception e) {
			log.error("ClientAccessUtil accesssForEntity excepion", e);
		}
		return result;
	}

	public <T> List<T> accesssForList(String url, Map<String, String> headerMap, String body, Class<T> clazz) {
		List<T> result = null;
		try {
			log.debug("ClientAccessUtil accesssForList url : {}, header:{} , body : {} ", url,
					JSON.toJSONString(headerMap), body);
			String response = SSLClientUtil.doPost(url, body, headerMap);
			log.debug("ClientAccessUtil accesssForList response : {}", response);
			result = parseListResult(clazz, response);
		} catch (Exception e) {
			log.error("ClientAccessUtil accesssForList excepion", e);
		}
		return result;
	}

	public static <T> T parseEntityResult(Class<T> clazz, String response) {
		if (StringUtils.isNotEmpty(response)) {
			JSONObject jsonObject = JSON.parseObject(response);
			String message_id = jsonObject.getString("messageId");
			if (StringUtils.isNotEmpty(message_id) && "10000".equals(message_id)) {
				String body = jsonObject.getString("body");
				if (body != null) {
					String jsonString = JSON.toJSONString(body);
					return JSON.parseObject(jsonString, clazz);
				}
			}
		}
		return null;
	}

	public <T> List<T> parseListResult(Class<T> clazz, String response) {
		if (StringUtils.isNotEmpty(response)) {
			JSONObject jsonObject = JSON.parseObject(response);
			String message_id = jsonObject.getString("messageId");
			if (StringUtils.isNotEmpty(message_id) && "10000".equals(message_id)) {
				String body = jsonObject.getString("body");
				if (body != null) {
					return JSON.parseArray(body, clazz);
				}
			}
		}
		return new ArrayList<>();
	}

}
