package com.yamibuy.ec.core.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.alibaba.fastjson.JSON;
import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;
import com.yamibuy.ec.core.entity.EventTrackEmailBody;
import com.yamibuy.ec.core.entity.EventTrackEmailBodyParam;
import com.yamibuy.ec.core.entity.EventTrackEmailEntity;
import com.yamibuy.ec.core.entity.EventTrackEmailHeader;
import com.yamibuy.ec.core.entity.Token;

public class EventTrackEmailUtils {

	private EventTrackEmailUtils() {
		super();
	}
	
	private static String base64Encypt(Object entity) {
		String jsonString = JSON.toJSONString(entity);
		byte[] textByte = jsonString.getBytes(StandardCharsets.UTF_8);
		Encoder encoder = Base64.getEncoder();
		return encoder.encodeToString(textByte);
	}
	
	private static String getShamToken(Integer user_id) {
		String auth = UUID.randomUUID().toString();
		auth =auth.replace("-", "");
		
		Random random = new Random();
		Integer salt = random.nextInt(8999);
		salt = salt + 1000;

		Token shamToken = new Token();
		shamToken.setExp(YamiDateUtil.get_LA_Second() + 14515200);
		shamToken.setData(String.valueOf(user_id));
		shamToken.setAuth(auth);
		shamToken.setSalt(String.valueOf(salt));
		shamToken.setIsLogin(1);
		return base64Encypt(shamToken);
	}
	
	/**
	   *    参数传递的不全会返回null，注意程序空指针
	 * @param event_track_url 大数据埋点url，例如 https://bi.api.yamibuy.com/logcollect/gif/web/emailtrack.gif
	 * @param token  能自己拿到token，用自己拿到的，实在拿不到可以不传这个
	 * @param user_id 用户编号必填
	 * @param email_type  邮件类型必填
	 * @param language 语言 zh_CN 或者 ec_US
	 * @param order_id 订单编号，没有可以不填
	 * @return 返回url，可以直接放入src 或者 href中
	 */
	public static String getEmailOpenData(String event_track_url,String token,Integer user_id,String email_type,String language,Integer order_id) {
		
		if(user_id == null 
				|| StringUtils.isEmpty(email_type) 
				|| StringUtils.isEmpty(language) 
				|| StringUtils.isEmpty(event_track_url)) {
			return null;
		}
		
		EventTrackEmailEntity entity = buildEntity(token,user_id,"event_email_open",email_type,language,order_id,null);
		
		String data = base64Encypt(entity);
		
		return String.format("%s?data=%s", event_track_url, data);
	}
	
	/**
	   *   参数传递的不全会返回null，注意程序空指针
	 * @param forward_service_url  转发服务的url必填，自己项目中配置的，例如 http://ecapi.yamibuy.net/ec-common/forword_url
	 * @param target_url 目标url必填，你要跳转到的url，例如facebook
	 * @param token 能自己拿到token，用自己拿到的，实在拿不到可以不传这个
	 * @param user_id 用户编号必填
	 * @param email_type 邮件类型必填
	 * @param language 语言 zh_CN 或者 ec_US
	 * @param order_id 订单编号，没有可以不填
	 * @param click_note 访问网址的名字必填
	 * @return 返回url，可以直接放入src 或者 href中
	 */
	public static String getExtranetLinkData(String forward_service_url,String target_url,String token,Integer user_id,String email_type,String language,Integer order_id,String click_note) {
		
		if(user_id == null 
				|| StringUtils.isEmpty(email_type) 
				|| StringUtils.isEmpty(language) 
				|| StringUtils.isEmpty(forward_service_url) 
				|| StringUtils.isEmpty(target_url)
				|| StringUtils.isEmpty(click_note)) {
			return null;
		}
		
		EventTrackEmailEntity entity = buildEntity(token,user_id,"event_email_click",email_type,language,order_id,click_note);
		
		String data = base64Encypt(entity);
		
		String target_encode_url;
		try {
			target_encode_url = URLEncoder.encode(target_url,StandardCharsets.UTF_8.toString());
		} catch (UnsupportedEncodingException e) {
			throw new YamibuyException(YamibuyMessageCode.SYSTEMERROR.getCode());
		}
		
		return String.format("%s?data=%s&url=%s", forward_service_url , data, target_encode_url);
		
	}
	
	private static EventTrackEmailEntity buildEntity(String token,Integer user_id,String event_name,String email_type,String language,Integer order_id,String click_note) {
		
		EventTrackEmailHeader header = new EventTrackEmailHeader();
		header.setToken(StringUtils.isEmpty(token) ? getShamToken(user_id) : token);
		
		List<EventTrackEmailBodyParam> params = new ArrayList<>();
		
		EventTrackEmailBodyParam param1 = new EventTrackEmailBodyParam();
		param1.setName("email_type");
		param1.setValue(email_type);
		params.add(param1);
		
		EventTrackEmailBodyParam param2 = new EventTrackEmailBodyParam();
		param2.setName("language");
		param2.setValue(language);
		params.add(param2);
		
		EventTrackEmailBodyParam param3 = new EventTrackEmailBodyParam();
		param3.setName("user_id");
		param3.setValue(String.valueOf(user_id));
		params.add(param3);
		
		if(order_id != null && order_id != 0) {
			EventTrackEmailBodyParam param4 = new EventTrackEmailBodyParam();
			param4.setName("order_id");
			param4.setValue(String.valueOf(order_id));
			params.add(param4);
		}
		
		if(!StringUtils.isEmpty(click_note)) {
			EventTrackEmailBodyParam param5 = new EventTrackEmailBodyParam();
			param5.setName("click_note");
			param5.setValue(click_note);
			params.add(param5);
		}
		
		EventTrackEmailBody body = new EventTrackEmailBody();
		body.setEvent_name(event_name);
		body.setEvent_parameters(params);
		
		EventTrackEmailEntity entity = new EventTrackEmailEntity();
		entity.setHeader(header);
		entity.setBody(body);
		
		return entity;
	}

}
