package com.yamibuy.ec.core.util;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 固定数量线程池
 */
public final class FixedThreadPoolUtil {
    private static ExecutorService executorService;

    private static final Integer NUMBER_OF_THREADS = 2048;

    private static class SigleClass {
        private static ExecutorService executor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    }

    private static ExecutorService getInstance() {
        if (null == executorService) {
            executorService = SigleClass.executor;
        }
        return executorService;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static Future doExecutor(Callable callable) {
        getInstance();
        return executorService.submit(callable);
    }

    public static void doExecutor(Runnable runnable) {
        getInstance();
        executorService.execute(runnable);
    }
}
