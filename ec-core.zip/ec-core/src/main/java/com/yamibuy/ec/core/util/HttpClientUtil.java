package com.yamibuy.ec.core.util;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author kevin.hu
 *
 */
@Slf4j
public final class HttpClientUtil {

    private static PoolingHttpClientConnectionManager poolingHttpClientConnectionManager;

    private static final Integer CON_MAX_TOTAL = 20;

    private static final Integer CON_MAX_PERROUTE = 2;
    
    private static class PoolSingle {
        private static PoolingHttpClientConnectionManager pool = new PoolingHttpClientConnectionManager();
        private PoolSingle(){}
    }

    private static PoolingHttpClientConnectionManager getInstance() {
        poolingHttpClientConnectionManager = PoolSingle.pool;
        if (null != poolingHttpClientConnectionManager) {
            poolingHttpClientConnectionManager.setMaxTotal(CON_MAX_TOTAL);// 整个连接池最大连接数
            poolingHttpClientConnectionManager.setDefaultMaxPerRoute(CON_MAX_PERROUTE);// 每路由最大连接数，默认值是2
        }
        return poolingHttpClientConnectionManager;
    }

    private static CloseableHttpClient getCloseableHttpClient() {
        getInstance();
        return HttpClients.custom().setConnectionManager(poolingHttpClientConnectionManager).build();
    }

    public static String doGet(String url, Map<String, String> param) {

        // 创建Httpclient对象
        CloseableHttpClient httpclient = getCloseableHttpClient();

        String resultString = null;
        CloseableHttpResponse response = null;
        URI uri = null;
        try {
            // 创建uri
            URIBuilder uriBuilder = new URIBuilder(url);
            if (param != null) {
                for (Entry<String, String> entry : param.entrySet()) {
                	String key = entry.getKey();
                    uriBuilder.addParameter(key, param.get(key));
                }
            }
            uri = uriBuilder.build();

            // 创建http GET请求
            HttpGet httpGet = new HttpGet(uri);

            // 执行请求
            response = httpclient.execute(httpGet);
            log.info("[ httpClient ] GET url : {}", uri.toURL());
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
			log.info("[ httpClient ] GET response : {}", jsonString);

            // 判断返回状态是否为200
            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "UTF-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] GET failed : {}" + uri, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", uri, e);
            }
        }
        return resultString;
    }

    public static String doGet(String url) {
        return doGet(url, null);
    }

    public static String doPost(String url, Map<String, String> param) {
        // 创建Httpclient对象
        CloseableHttpClient httpClient = getCloseableHttpClient();
        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);

            // 创建参数列表
            if (param != null) {
                List<NameValuePair> paramList = new ArrayList<>();
                for (Entry<String, String> engty : param.entrySet()) {
                	String key = engty.getKey();
                    paramList.add(new BasicNameValuePair(key, param.get(key)));
                }
                // 模拟表单
                UrlEncodedFormEntity entity = new UrlEncodedFormEntity(paramList);
                httpPost.setEntity(entity);
            }
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
			log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : " + url, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : " + url, e);
            }
        }
        return resultString;
    }

    public static String doPost(String url) {
        return doPost(url, null);
    }

    public static String doPostJson(String url, String json) {
        // 创建Httpclient对象

        CloseableHttpClient httpClient = getCloseableHttpClient();
        CloseableHttpResponse response = null;
        String resultString = null;
        try {
            // 创建Http Post请求
            HttpPost httpPost = new HttpPost(url);
            // 创建请求内容
            StringEntity entity = new StringEntity(json, ContentType.APPLICATION_JSON);
            httpPost.setEntity(entity);
            // 执行http请求
            response = httpClient.execute(httpPost);
            log.info("[ httpClient ] POST url : {}", url);
            String jsonString = JSON.toJSONString(response == null ? "{}" : response);
			log.info("[ httpClient ] POST response : {}", jsonString);

            if (null != response && response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "utf-8");
            }
        } catch (Exception e) {
            log.error("[ httpClient ] POST failed : {}", url, e);
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                log.error("[ httpClient ] Release resources failed : {}", url, e);
            }
        }
        return resultString;
    }

}