package com.yamibuy.ec.core.util;

import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <br>
 * <b>功能：</b>Check<br>
 * <b>作者：</b>www.yamibuy.com<br>
 * <b>日期：</b> May 1, 2016 <br>
 * <b>版权所有：</b>版权所有(C) 2016，www.yamibuy.com<br>
 */
@Slf4j
public final class IPUtils {
	
	private static final String UNKNOW = "unknown";

	public static String getIpAddress(HttpServletRequest request) {
		
		String ip = request.getHeader("CF-Connecting-IP"); // cloudflare
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-Forwarded-For"); // aliyun 负载
		}
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-Real-IP"); //gateway nignx
		}
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");//Apache + WebLogic
		}
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");//Apache + WebLogic
		}
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || UNKNOW.equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		
		if(ip != null && ip.contains(",")) {
			ip = ip.substring(0, ip.indexOf(","));
		}
		log.debug("最终获取真实IP地址为：{}",ip);
		
		return ip;
	}
}
