package com.yamibuy.ec.core.util;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * list操作工具类
 */
public final class ListUtils
{
	public static boolean isNullorEmpty(Collection<?> list)
	{
		return null == list || list.isEmpty();
	}

	public static boolean isNotEmpty(Collection<?> list)
	{
		return null != list && !list.isEmpty();
	}
	
	/**
	 * 求ls对ls2的差集,即ls中有，但ls2中没有的
	 * 
	 * 注意：对应的实体必须重写equals方法
	 * @param list
	 * @param list2
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> diff(List<T> list, List<T> list2) {
		if(list == null || list.isEmpty()){
			return Collections.emptyList();
		}
		if(list2 == null || list2.isEmpty()){
			return list;
		}
		Object[] arr = new Object[list.size()];
		List<T> copyList = (List<T>) Arrays.asList(arr);
		Collections.copy(copyList, list);
		copyList.removeAll(list2);
		return copyList;
	}
}
