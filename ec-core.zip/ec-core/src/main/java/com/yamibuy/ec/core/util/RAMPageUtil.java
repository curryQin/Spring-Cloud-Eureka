package com.yamibuy.ec.core.util;

import java.util.Collections;
import java.util.List;

/**
 * 内存分页器
 */
public class RAMPageUtil {

	/**
	 * 根据传入的List和页码返回分页后的List
	 * 
	 * @param original
	 *            全量的List数据
	 * @param pageNum
	 *            页码(0,1,2...)
	 * @param pageSize
	 *            每页数据条数
	 * @param <T>
	 * @return 返回分页后的对应页码页面的List
	 */
	public static <T> List<T> page(List<T> original, int pageNum, int pageSize) {
		List<T> list = Collections.emptyList();
		if (ListUtils.isNotEmpty(original)) {
			int fromIndex = pageNum * pageSize;
			list = pageByIndex(original, fromIndex, pageSize);
		}
		return list;
	}

	/**
	 * @param original
	 * @param fromIndex
	 * @param pageSize
	 * @return
	 */
	public static <T> List<T> pageByIndex(List<T> original, int fromIndex, int pageSize) {
		List<T> list = Collections.emptyList();
		if (ListUtils.isNotEmpty(original)) {
			int size = original.size();
			int toIndex = fromIndex + pageSize;
			if (toIndex < size) {
				list = original.subList(fromIndex, toIndex);
			} else if (fromIndex < size) {
				list = original.subList(fromIndex, size);
			}
		}
		return list;
	}
}