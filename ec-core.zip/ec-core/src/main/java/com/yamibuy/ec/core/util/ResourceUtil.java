package com.yamibuy.ec.core.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.yamibuy.ec.core.entity.MessageCode;

import lombok.extern.slf4j.Slf4j;

/**
 * 静态资源国际化中英文
 */
@Slf4j
public final class ResourceUtil {

	private static final String BUNDLE_BASE_NAME_RESOURCE = "resource";
	private static final String BUNDLE_BASE_NAME_MESSAGES = "messages";

	/**
	 * 根据语言获取资源文件
	 * 
	 * @param locale
	 */
	public static List<MessageCode> getMessageCodes(Locale locale, String baseName) {
		List<MessageCode> messageCodes = new ArrayList<>();
		ResourceBundle messageSource = ResourceBundle.getBundle(baseName, locale);

		for (String key : messageSource.keySet()) {
			String value = messageSource.getString(key);
			MessageCode messageCode = new MessageCode(key, value);
			messageCodes.add(messageCode);
		}
		return messageCodes;
	}

	/**
	 * 根据code获取错误信息
	 */
	public static String getMessage(String messageCode) {
		Locale locale = Locale.getDefault();
		String result = "";
		try {
			result = getMessage(messageCode, BUNDLE_BASE_NAME_RESOURCE, locale);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			result = getMessage(messageCode, BUNDLE_BASE_NAME_MESSAGES, locale);
		}

		return result;
	}

	public static String getMessage(String messageCode, String baseName, Locale locale) {
		ResourceBundle messageSource = ResourceBundle.getBundle(baseName, locale);
		String result = "";
		try {
			result = messageSource.getString(messageCode);
		} catch (Exception e) {
//			log.debug(e.getMessage(), e);
			if (!BUNDLE_BASE_NAME_MESSAGES.equalsIgnoreCase(baseName)) {
				return getMessage(messageCode, BUNDLE_BASE_NAME_MESSAGES, locale);
			}
			return messageCode;
		}

		return result;
	}
}
