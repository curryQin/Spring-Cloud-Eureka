package com.yamibuy.ec.core.util;

import org.hamcrest.Matchers;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.yamibuy.ec.core.common.YamibuyMessageCode;

import lombok.extern.slf4j.Slf4j;

/**
 * Rest测试工具类
 */
@Slf4j
public final class RestTestUtil{
	
	private static final String HEADER_TOKEN_NAME = "token";
	private static final String HEADER_TOKEN_VALUE = "Alven.wang";
	private static final String RESPONSE_SUCCESS_KEY = "messageId";
	
	/**
	 * post类型MockMvcBuilder
	 * 
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean postMockMvcBuilder(MockMvc mockMvc, String url, String requestJson){
		return postMockMvcBuilder(mockMvc, url, requestJson, HEADER_TOKEN_VALUE);
	}

	/**
	 * post类型MockMvcBuilder
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @param token token
	 * @return
	 */
	public static boolean postMockMvcBuilder(MockMvc mockMvc, String url, String requestJson, String token) {
		try {
			mockMvc.perform(
					MockMvcRequestBuilders.post(url)
							.header(HEADER_TOKEN_NAME, token)
							.contentType(MediaType.APPLICATION_JSON)
							.content(requestJson))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andExpect(
							MockMvcResultMatchers.jsonPath(
									RESPONSE_SUCCESS_KEY,
									Matchers.is(YamibuyMessageCode.SUCCESS.getCode()))
					);

		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
			return false;
		}
		return true;
	}

	/**
	 * get类型MockMvcBuilder
	 *
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static MvcResult postMockMvcResult(MockMvc mockMvc, String url, String requestJson, String token){
		MvcResult result = null;
		try {
			result = mockMvc.perform(
					MockMvcRequestBuilders.post(url)
							.header(HEADER_TOKEN_NAME, token)
							.contentType(MediaType.APPLICATION_JSON)
							.content(requestJson))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andReturn();

		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
		}
		return result;
	}

	/**
	 * get类型MockMvcBuilder(无参)
	 * 
	 * @param mockMvc
	 * @param url 路径
	 * @return
	 */
	public static boolean getMockMvcBuilder(MockMvc mockMvc, String url){
		try {
			mockMvc.perform(
				MockMvcRequestBuilders.get(url)
					.header(HEADER_TOKEN_NAME, HEADER_TOKEN_VALUE))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andExpect(
						MockMvcResultMatchers.jsonPath(
								RESPONSE_SUCCESS_KEY, 
								Matchers.is(YamibuyMessageCode.SUCCESS.getCode()))
						);
			
		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
			return false;
		}
		return true;
	} 
	
	/**
	 * get类型MockMvcBuilder
	 * 
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean getMockMvcBuilder(MockMvc mockMvc, String url, String requestJson){
		return getMockMvcBuilder(mockMvc, url, requestJson, HEADER_TOKEN_VALUE);
	}

	/**
	 * get类型MockMvcBuilder
	 *
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean getMockMvcBuilder(MockMvc mockMvc, String url, String requestJson, String token){
		try {
			mockMvc.perform(
					MockMvcRequestBuilders.get(url)
							.header(HEADER_TOKEN_NAME, token)
							.contentType(MediaType.APPLICATION_JSON)
							.content(requestJson))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andExpect(
							MockMvcResultMatchers.jsonPath(
									RESPONSE_SUCCESS_KEY,
									Matchers.is(YamibuyMessageCode.SUCCESS.getCode()))
					);

		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
			return false;
		}
		return true;
	}

	/**
	 * get类型MockMvcBuilder
	 *
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static MvcResult getMockMvcResult(MockMvc mockMvc, String url, String requestJson, String token){
		MvcResult result = null;
		try {
			result = mockMvc.perform(
					MockMvcRequestBuilders.get(url)
							.header(HEADER_TOKEN_NAME, token)
							.contentType(MediaType.APPLICATION_JSON)
							.content(requestJson))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andReturn();

		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
		}
		return result;
	}

	/**
	 * delete类型MockMvcBuilder
	 * 
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean deleteMockMvcBuilder(MockMvc mockMvc, String url, String requestJson){
		return deleteMockMvcBuilder(mockMvc, url, requestJson, HEADER_TOKEN_VALUE);
	}

	/**
	 * delete类型MockMvcBuilder
	 *
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean deleteMockMvcBuilder(MockMvc mockMvc, String url, String requestJson, String token){
		try {
			mockMvc.perform(
					MockMvcRequestBuilders.delete(url)
							.header(HEADER_TOKEN_NAME, token)
							.contentType(MediaType.APPLICATION_JSON)
							.content(requestJson))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andExpect(
							MockMvcResultMatchers.jsonPath(
									RESPONSE_SUCCESS_KEY,
									Matchers.is(YamibuyMessageCode.SUCCESS.getCode()))
					);

		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
			return false;
		}
		return true;
	}

	/**
	 * put类型MockMvcBuilder
	 *
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean putMockMvcBuilder(MockMvc mockMvc, String url, String requestJson){
		return putMockMvcBuilder(mockMvc, url, requestJson, HEADER_TOKEN_VALUE);
	}

	/**
	 * put类型MockMvcBuilder
	 * 
	 * @param mockMvc
	 * @param url 路径
	 * @param requestJson  Json类型参数
	 * @return
	 */
	public static boolean putMockMvcBuilder(MockMvc mockMvc, String url, String requestJson, String token){
		try {
			mockMvc.perform(
				MockMvcRequestBuilders.put(url)
					.header(HEADER_TOKEN_NAME, token)
					.contentType(MediaType.APPLICATION_JSON)
					.content(requestJson))
					.andDo(MockMvcResultHandlers.print())
					.andExpect(MockMvcResultMatchers.status().isOk())
					.andExpect(
						MockMvcResultMatchers.jsonPath(
								RESPONSE_SUCCESS_KEY, 
								Matchers.is(YamibuyMessageCode.SUCCESS.getCode()))
						);
			
		} catch (Exception e) {
			log.debug(e.getLocalizedMessage(), e);
			return false;
		}
		return true;
	} 
}
