package com.yamibuy.ec.core.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;

import com.yamibuy.ec.core.common.YamibuyConstant;

import lombok.extern.slf4j.Slf4j;

/**
 * https client 请求类
 */
@Slf4j
public final class SSLClientUtil {
	
	/**
	 * 默认超时时间，单位毫秒
	 */
	private static final int DEFAULT_TIMEOUT = 30000;

	/**
	 * @param url
	 * @return
	 */
	public static String doGet(String url) {
		return doGet(url, YamibuyConstant.STRING_DEFAULT);
	}
	
	/**
	 * @param url
	 * @param connectTimeout
	 * @return
	 */
	public static String doGet(String url, int connectTimeout) {
		return doGet(url, YamibuyConstant.STRING_DEFAULT, connectTimeout);
	}
	
	/**
	 * @param url
	 * @param params
	 * @return
	 */
	public static String doGet(String url, Map<String, String> params) {
		return doGet(initParams(url, params));
	}

	/**
	 * @param url
	 * @param params
	 * @return
	 */
	public static String doGet(String url, Map<String, String> params, int connectTimeout) {
		return doGet(initParams(url, params), connectTimeout);
	}
	
	/**
	 * @param url
	 * @param token
	 * @param params
	 * @return
	 */
	public static String doGet(String url, String token, Map<String, String> params) {
		return doGet(initParams(url, params), token);
	}

	/**
	 * @param url
	 * @param token
	 * @param params
	 * @return
	 */
	public static String doGet(String url, String token, Map<String, String> params, int connectTimeout) {
		return doGet(initParams(url, params), token, connectTimeout);
	}
	
	/**
	 * @param url
	 * @param token
	 * @return
	 */
	public static String doGet(String url, String token) {
		// 设置默认超时时间30s
		return doGet(url, token, DEFAULT_TIMEOUT);
	}

	/**
	 * @param url
	 * @param token
	 * @return
	 */
	public static String doGet(String url, String token, int connectTimeout) {
		CloseableHttpClient httpclient = null;
		String result = "";
		try {
			httpclient = SSLClientUtil.createHttpsClient();
			HttpGet httpget = new HttpGet(url);
			// 设置请求超时时间
			RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(connectTimeout).build();
			httpget.setConfig(defaultRequestConfig);
			if (StringUtils.isNotEmpty(token)) {
				httpget.setHeader(YamibuyConstant.KEY_TOKEN, token);
			}
			try (CloseableHttpResponse response = httpclient.execute(httpget)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		} finally {
			closeHttpClient(httpclient);
		}
		return result;
	}
	
	/**
	 * @param url
	 * @param token
	 * @return
	 */
	public static String doGet(String url , Map<String,String> headerMap , Map<String,String> params) {
		return doGet(url, headerMap, params, DEFAULT_TIMEOUT);
	}
	
	/**
	 * @param url
	 * @param token
	 * @return
	 */
	public static String doGetWithHeader(String url, Map<String, String> headerMap) {
		return doGet(url, headerMap, null, DEFAULT_TIMEOUT);
	}
	
	/**
	 * @param url
	 * @param token
	 * @return
	 */
	public static String doGet(String url, Map<String, String> headerMap, Map<String, String> params,
			int connectTimeout) {
		CloseableHttpClient httpclient = null;
		String result = "";
		try {
			httpclient = SSLClientUtil.createHttpsClient();
			HttpGet httpget = new HttpGet(initParams(url, params));
			// 设置请求超时时间
			RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(connectTimeout).build();
			httpget.setConfig(defaultRequestConfig);
			if (headerMap != null && !headerMap.isEmpty()) {
				for (Entry<String, String> entry : headerMap.entrySet()) {
					httpget.setHeader(entry.getKey(), entry.getValue());
				}
			}
			try (CloseableHttpResponse response = httpclient.execute(httpget)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		} finally {
			closeHttpClient(httpclient);
		}
		return result;
	}

	/**
	 * @param url
	 * @return
	 */
	public static String doPatchUrl(String url) {
		CloseableHttpClient httpclient = null;
		String result = "";
		try {
			httpclient = SSLClientUtil.createHttpsClient();
			HttpPatch httpPatch = new HttpPatch(url);
			// 设置请求超时时间
			RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(DEFAULT_TIMEOUT).build();
			httpPatch.setConfig(defaultRequestConfig);
			try (CloseableHttpResponse response = httpclient.execute(httpPatch)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		} finally {
			closeHttpClient(httpclient);
		}
		return result;
	}

	/**
	 * @param url
	 * @param jsonBody
	 * @return
	 */
	public static String doPost(String url, String jsonBody) {
		return doPost(url, jsonBody, DEFAULT_TIMEOUT);
	}
	
	/**
	 * @param url
	 * @param jsonBody
	 * @return
	 */
	public static String doPost(String url, String jsonBody, int connectTimeout) {
		return doPost(url, jsonBody, "", connectTimeout);
	}

	/**
	 * @param url
	 * @param jsonBody
	 * @param token
	 * @return
	 */
	public static String doPost(String url, String jsonBody, String token) {
		return doPost(url, jsonBody, token, DEFAULT_TIMEOUT);
	}
	
	/**
	 * @param url
	 * @param jsonBody
	 * @param token
	 * @return
	 */
	public static String doPost(String url, String jsonBody, String token, int connectTimeout) {
		CloseableHttpClient httpclient = null;
		String result = "";
		try {
			httpclient = SSLClientUtil.createHttpsClient();
			HttpPost httpPost = new HttpPost(url);
			// 设置请求超时时间
			RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(connectTimeout).build();
			httpPost.setConfig(defaultRequestConfig);
			if (StringUtils.isNotEmpty(token)) {
				httpPost.setHeader(YamibuyConstant.KEY_TOKEN, token);
			}
			// 创建请求内容
			StringEntity requestEntity = new StringEntity(jsonBody, ContentType.APPLICATION_JSON);
			httpPost.setEntity(requestEntity);
			try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		} finally {
			closeHttpClient(httpclient);
		}
		return result;
	}
	
	/**
	 * @param url
	 * @param jsonBody
	 * @param token
	 * @return
	 */
	public static String doPost(String url, String jsonBody, Map<String, String> headerMap) {
		return doPost(url, jsonBody, headerMap, DEFAULT_TIMEOUT);
	}
	
	/**
	 * @param url
	 * @param jsonBody
	 * @param token
	 * @return
	 */
	public static String doPost(String url, String jsonBody, Map<String, String> headerMap, int connectTimeout) {
		CloseableHttpClient httpclient = null;
		String result = "";
		try {
			httpclient = SSLClientUtil.createHttpsClient();
			HttpPost httpPost = new HttpPost(url);
			// 设置请求超时时间
			RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(connectTimeout).build();
			httpPost.setConfig(defaultRequestConfig);
			if (headerMap!=null && !headerMap.isEmpty()) {
				for (Entry<String, String> entry : headerMap.entrySet()) {
					httpPost.setHeader(entry.getKey(), entry.getValue());
				}
			}
			// 创建请求内容
			StringEntity requestEntity = new StringEntity(jsonBody, ContentType.APPLICATION_JSON);
			httpPost.setEntity(requestEntity);
			try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		} finally {
			closeHttpClient(httpclient);
		}
		return result;
	}
	
	/**
	 * @param url
	 * @param jsonBody
	 * @param token
	 * @return
	 */
	public static String doPut(String url, String jsonBody, Map<String, String> headerMap) {
		String result = "";
		try (CloseableHttpClient httpclient = SSLClientUtil.createHttpsClient() ) {
			HttpPut httpPut = new HttpPut(url);
			if (headerMap!=null && !headerMap.isEmpty()) {
				for (Entry<String, String> entry : headerMap.entrySet()) {
					httpPut.setHeader(entry.getKey(), entry.getValue());
				}
			}
			// 创建请求内容
			StringEntity requestEntity = new StringEntity(jsonBody, ContentType.APPLICATION_JSON);
			httpPut.setEntity(requestEntity);
			try (CloseableHttpResponse response = httpclient.execute(httpPut)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		}
		return result;
	}
	
	public static String doDelete(String url,Map<String, String> headerMap , Map<String,String> params) {
		String result = "";
		try (CloseableHttpClient httpclient = SSLClientUtil.createHttpsClient() ) {
			HttpDelete httpDelete = new HttpDelete(initParams(url,params));
			if (headerMap!=null && !headerMap.isEmpty()) {
				for (Entry<String, String> entry : headerMap.entrySet()) {
					httpDelete.setHeader(entry.getKey(), entry.getValue());
				}
			}
			try (CloseableHttpResponse response = httpclient.execute(httpDelete)) {
				HttpEntity entity = response.getEntity();
				result = EntityUtils.toString(entity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		}
		return result;
	}

	/**
	 * 创建https client
	 * 
	 * @return
	 * @throws Exception
	 */
	private static CloseableHttpClient createHttpsClient() throws Exception {
		TrustAnyStrategy trustStrategy = new TrustAnyStrategy();
		SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(trustStrategy).build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" , "TLSv1.1" , "TLSv1.2" }, null,
		        SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		return HttpClients.custom().setSSLSocketFactory(sslsf).setConnectionTimeToLive(5, TimeUnit.SECONDS).build();
	}
	
	/**
	 * 关闭client
	 * 
	 * @param httpclient
	 */
	private static void closeHttpClient(CloseableHttpClient httpclient) {
		if (null != httpclient) {
			try {
				httpclient.close();
			} catch (IOException e) {
				log.error(e.getLocalizedMessage(), e);
			}
		}
	}

	/**
	 * 功能描述: 构造请求参数
	 * 
	 * @return 返回类型:
	 */
	public static String initParams(String url, Map<String, String> params) {
		if (null == params || params.isEmpty()) {
			return url;
		}
		StringBuilder sb = new StringBuilder(url);
		if (url.indexOf('?') == -1) {
			sb.append('?');
		}
		sb.append(map2Url(params));
		return sb.toString();
	}

	/**
	 * map构造url
	 * 
	 * @return 返回类型:
	 * @throws Exception
	 */
	public static String map2Url(Map<String, String> paramToMap) {
		if (null == paramToMap || paramToMap.isEmpty()) {
			return null;
		}
		StringBuilder url = new StringBuilder();
		boolean isfirst = true;
		for (Entry<String, String> entry : paramToMap.entrySet()) {
			if (isfirst) {
				isfirst = false;
			} else {
				url.append("&");
			}
			url.append(entry.getKey()).append("=");
			String value = entry.getValue();
			if (!StringUtils.isEmpty(value)) {
				try {
					url.append(URLEncoder.encode(value, StandardCharsets.UTF_8.name()));
				} catch (UnsupportedEncodingException e) {
					log.debug(e.getLocalizedMessage(), e);
				}
			}
		}
		return url.toString();
	}
	
	/**
	 * @param url
	 * @param jsonBody
	 * @param token
	 * @return
	 */
	public static String doFormPost(String url, Map<String, String> formData, Map<String, String> headerMap) {
		CloseableHttpClient httpclient = null;
		String result = "";
		try {
			httpclient = SSLClientUtil.createHttpsClient();
			HttpPost httpPost = new HttpPost(url);
			if (headerMap!=null && !headerMap.isEmpty()) {
				for (Entry<String, String> entry : headerMap.entrySet()) {
					httpPost.setHeader(entry.getKey(), entry.getValue());
				}
			}
			
			List<BasicNameValuePair> formparams = new ArrayList<>();  
			for (Entry<String,String> entry : formData.entrySet()) {
				formparams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));  
			}
		    UrlEncodedFormEntity uefEntity = new UrlEncodedFormEntity(formparams, "UTF-8");  
			
			
			httpPost.setEntity(uefEntity);
			try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
				HttpEntity responseEntity = response.getEntity();
				result = EntityUtils.toString(responseEntity, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			log.error(e.getLocalizedMessage(), e);
		} finally {
			closeHttpClient(httpclient);
		}
		return result;
	}
}
