package com.yamibuy.ec.core.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.core.env.Environment;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.alibaba.fastjson.JSON;
import com.yamibuy.ec.core.common.DomainEmailConfigUpdater;
import com.yamibuy.ec.core.entity.DomainEmailConfig;
import com.yamibuy.ec.core.entity.Sendmail;
import com.yamibuy.ec.core.service.SendmailService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public final class SendMailUtil {
	private static DomainEmailConfigUpdater domainEmailConfigUpdater;
	private static String lastExceptionFlag;

	private static DomainEmailConfigUpdater getDomainConfigUpdater() {
		if (null == domainEmailConfigUpdater) {
			domainEmailConfigUpdater = SpringfactoryUtils.getBean(DomainEmailConfigUpdater.class);
		}

		return domainEmailConfigUpdater;
	}

	public static void send(Sendmail sendMail) {
		SendmailService service = SpringfactoryUtils.getBean(SendmailService.class);
		service.insert(sendMail);
	}

	/**
	 * 异常时发送邮件到各domain负责人
	 * 
	 * @param profile
	 *            所属环境
	 * 
	 * @param templateEngine
	 * @param ex
	 * @param point
	 * @param exceptionRefKey
	 * @return
	 */
	public static void sendExceptionMail(Environment env, TemplateEngine templateEngine, Exception ex,
			ProceedingJoinPoint point, String exceptionRefKey) {
		Sendmail sendMail = new Sendmail();
		String applicationName = System.getProperty("@appId");
		String profile = env.getProperty("spring.profiles.active");
		DomainEmailConfig domainConfig = getDomainConfigUpdater().getConfigByName(applicationName);
		if (null == domainConfig && profile.contains("prd")) {
			// 生产环境无配置则替换为默认收件人
			domainConfig = new DomainEmailConfig();
			domainConfig.setEmail_to("charles.kou@yamibuy.com");
			domainConfig.setEmail_cc("");
		}
		String ownerEmail = domainConfig.getEmail_to();
		String name = ownerEmail.substring(0, ownerEmail.indexOf('@'));
		sendMail.setName(name);
		sendMail.setEmail(ownerEmail);
		sendMail.setCc(domainConfig.getEmail_cc());
		if ("local".equalsIgnoreCase(profile)) {
			log.info("local 环境服务发生异常，请检查");
			return;
		}
		sendMail.setSubject(profile + "环境 " + applicationName + "服务发生异常，请及时处理！！！");
		Long sendTime = System.currentTimeMillis() / 1000;
		sendMail.setSend_time(sendTime);
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw, true);
		ex.printStackTrace(pw);
		String stacktrace = sw.toString();
		Context context = new Context();
		// 服务器信息
		context.setVariable("module", applicationName);
		// 请求信息
		String className = point.getTarget().getClass().getName();
		String methodName = point.getSignature().getName();
		Object[] obj = point.getArgs();
		context.setVariable("method", className + "." + methodName);
		context.setVariable("param", JSON.toJSONString(obj));
		// 异常信息
		context.setVariable("exceptionRefKey", exceptionRefKey);
		context.setVariable("stackmessage", ex.toString());
		context.setVariable("stacktrace", stacktrace);
		String emailContent = templateEngine.process("Exception", context);
		sendMail.setContent(emailContent);
		String flag = className + "." + methodName + "." + ex.toString();
		if (!flag.equals(lastExceptionFlag)) {
			lastExceptionFlag = flag;
			SendMailUtil.send(sendMail);
			log.info("异常邮件发送成功 exception mail send success");
		}
	}
}
