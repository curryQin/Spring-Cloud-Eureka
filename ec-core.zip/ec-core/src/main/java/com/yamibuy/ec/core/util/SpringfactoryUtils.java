package com.yamibuy.ec.core.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * spring bean获取工具
 */
@Component
public final class SpringfactoryUtils implements ApplicationContextAware {

	private static ApplicationContext context;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		if (null == SpringfactoryUtils.context) {
			setContext(applicationContext);
		}
	}
	
	public static void setContext(ApplicationContext contextParam) {
		context = contextParam;
	}

	/**
	 * 通过class获取Bean.
	 * 
	 * @param clazz
	 * @return
	 */
	public static <T> T getBean(Class<T> clazz) {
		return context.getBean(clazz);
	}
	
	/**
	 * 获取配置属性
	 * @param key
	 * @return
	 */
	public static String getProperty(String key) {
		return context.getEnvironment().getProperty(key);
	}

	/**
	 * 通过name,以及Clazz返回指定的Bean
	 * 
	 * @param name
	 * @param clazz
	 * @return
	 */
	public static <T> T getBean(String name, Class<T> clazz) {
		return context.getBean(name, clazz);
	}

	/**
	 * 根据beanName名字取得bean
	 * 
	 * @param name
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getBean(String name) {
		return (T) context.getBean(name);
	}

}
