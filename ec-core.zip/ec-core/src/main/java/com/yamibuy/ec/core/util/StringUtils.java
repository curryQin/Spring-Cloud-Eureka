package com.yamibuy.ec.core.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.util.DigestUtils;

import com.yamibuy.ec.core.common.YamibuyConstant;
import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;

import lombok.extern.slf4j.Slf4j;

/**
 * 字符串处理工具类
 */
@Slf4j
public final class StringUtils
{
	public static boolean isEmpty(Object obj)
	{
		if (obj == null || YamibuyConstant.STRING_DEFAULT.equals(obj))
		{
			return true;
		}
		return false;
	}

	/**
	 * isNullOrEmpty.
	 * @param str
	 * @return
	 */
	public static boolean isNullOrEmpty(String str)
	{
		return null == str || str.length() == 0;
	}

	/**
	 * isNotEmpty
	 * @param str
	 * @return
	 */
	public static boolean isNotEmpty(String str)
	{
		return !isNullOrEmpty(str);
	}
	
	
	/**
	 * <pre>
	 * Function : Verify the Char whether is null or "" and whether is Active status, 
	 * if yes Response active Value, id no Response deactive Value
	 * </pre>
	 *  
	 * 
	 * @param string BigDecimal
	 * @param active Default Active Value
	 * @param deactive Default DeActive Value
	 * @return String
	 */
	public static String checkChar(String string, String active, String deactive)
	{
		return isNotEmpty(string) && active.equalsIgnoreCase(string) ? active : deactive;
	}

	/**
	 * <pre>
	 * Function : Verify the String whether is null or "" , 
	 * if yes Response defaultString , id no Response itself
	 * </pre>
	 * @param string String
	 * @param defaultString Default Value
	 * @return String
	 */
	public static String checkString(String string, String defaultString)
	{
		if (isEmpty(string))
		{
			return defaultString;
		}
		else
		{
			return string;
		}
	}

	/**
	 * base64编码
	 */
	public static String encode(String str) {
		byte[] bt = null;
		try{
			byte[] bytes = str.getBytes();
			bt = Base64.encodeBase64(bytes);
		}catch(Exception e){
			throw new YamibuyException(e, YamibuyMessageCode.SYSTEMERROR.getCode());
		}
		
		return new String(bt);
	}
	
	/**
	 * base64解码
	 * 
	 * @param string
	 * @return string
	 */
	public static String decode(String str) {
		byte[] bt = null;
		try{
			bt = Base64.decodeBase64(str);
		}catch(Exception e){
			throw new YamibuyException(e, YamibuyMessageCode.SYSTEMERROR.getCode(), e.getMessage());
		}
		return new String(bt);
	}
	
	/**
	 * <pre>
	 * Function : Verify the Integer whether is null or "" , 
	 * if yes Response defaultInteger , id no Response itself
	 * </pre>
	 * @param integer String
	 * @param defaultInteger Default Value
	 * @return Integer
	 */
	public static Integer checkInteger(Integer integer, Integer defaultInteger)
	{
		if (isEmpty(integer))
		{
			return defaultInteger;
		}
		else
		{
			return integer;
		}
	}
	
	public static String listToString(List<String> list)
	{
		if (null == list)
		{
			return null;
		}
		StringBuilder result = new StringBuilder();
		for (String string : list)
		{
			result.append(string + ",");
		}
		return result.substring(0, result.length() - 1);
	}
	
	/**
	 * 截取字符串中的数字
	 * @param str
	 * @return
	 */
	public static String getNumberic(String str) {
		if (null == str || str.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (char ch : str.toCharArray()) {
			if (Character.isDigit(ch)) {
				sb.append(ch);
			}
		}
		return sb.toString();
	}
	
	/**
	 * 转换为BigDecimal
	 * 
	 * @param value
	 * @return
	 */
	public static BigDecimal toBigDecimal(String value) {
		return BigDecimal.valueOf(Double.valueOf(value));
	}
	
	/**
	 * <pre>
	 * Function : Verify the BigDecimal whether is null or "" , 
	 * if yes Response defaultDecimal , id no Response itself
	 * </pre>
	 * @param bigDecimal BigDecimal
	 * @param defaultDecimal Default Value
	 * @return BigDecimal
	 */
	public static BigDecimal checkBigDecimal(BigDecimal bigDecimal,BigDecimal defaultDecimal)
	{
		if (isEmpty(bigDecimal))
		{
			return defaultDecimal;
		}
		return checkValue(bigDecimal, YamibuyMessageCode.WRONGVALUE_BIGDECIMAL.getCode());
	}
	
	/**
	 * item 尺寸 长宽高取消默认99999值，给0。   IM-416 为什么有一些item的长宽高默认尺寸是99999？
	 * 
	 * @param value
	 * @return
	 */
	public static BigDecimal checkSpceficBigDecimalbySize(BigDecimal bigDecimal,String messageID)
	{
		if (isEmpty(bigDecimal))
		{
			return new BigDecimal(0);
		}
		return checkValue(bigDecimal, messageID);
	}

	private static BigDecimal checkValue(BigDecimal bigDecimal, String messageID) {
		if (bigDecimal.compareTo(BigDecimal.ZERO) < 0 || bigDecimal.compareTo(BigDecimal.valueOf(99999999.99)) > 0 )
		{
			throw new YamibuyException("BigDecimal value have Error", messageID, bigDecimal.toString());
		}
		else
		{
			return bigDecimal;
		}
	}
	
	public static boolean isBlank(final CharSequence cs) {
        int strLen;
        if (cs == null || (strLen = cs.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(cs.charAt(i))) {
                return false;
            }
        }
        return true;
    }
	
	/**
     * MD5加密（多次）登陆
     * @param salt 
     * @param pwd 
     * @param enctimes 加密次数
     * @throws NoSuchAlgorithmException,UnsupportedEncodingException
     */
	public static String EncoderByMd5Old(String salt,String pwd,int enctimes) throws Exception {
		String saltTemp = salt;
		for(int i =0;i<enctimes;i++){
			saltTemp = EncoderByMd5(saltTemp, pwd);
		}
		return saltTemp;
	}
	
	/**
     * MD5加密（单次）登陆
     * @param salt 
     * @param pwd 
     * @throws NoSuchAlgorithmException,UnsupportedEncodingException
     */
	public static String EncoderByMd5(String salt, String pwd) throws Exception {
		return DigestUtils.md5DigestAsHex((salt + "||" + pwd).getBytes(StandardCharsets.UTF_8.name()));
	}
	
	/**
     * MD5加密（多次）登陆
     * @param salt 
     * @param pwd 
     * @param enctimes 加密次数
     * @throws NoSuchAlgorithmException,UnsupportedEncodingException
     */
	public static String EncoderByMd5(String salt, String pwd, int enctimes) throws Exception {
		String saltTemp = salt;
		for (int i = 0; i < enctimes; i++) {
			saltTemp = StringUtils.EncoderByMd5(saltTemp, pwd);
		}
		return saltTemp;
	}
	
	/**
     * MD5加密（单次）登陆(PHP way)
     * 老系统的加密算法
	 * 1.若有salt，则密码为md5(md5(password)+salt)
	 * 2.若没有，则密码为md5(password)
     * @param salt 
     * @param pwd 
     * @throws Exception
     */
	public static String EncoderByMd5Old(String salt, String pwd) throws Exception {
		byte[] digest = DigestUtils.md5Digest(pwd.getBytes(StandardCharsets.UTF_8.name()));
		BigInteger hash = new BigInteger(1, digest);
		String md5pwd = hash.toString(16);
		StringBuilder sb = new StringBuilder(md5pwd);
		while (sb.length() < 32) { // 40 for SHA-1
			sb.append("0").append(md5pwd);
		}
		md5pwd = sb.toString();
		if (salt != null && !salt.isEmpty()) {
			byte[] digestWithSalt = DigestUtils.md5Digest((md5pwd + salt).getBytes(StandardCharsets.UTF_8.name()));
			hash = new BigInteger(1, digestWithSalt);
			md5pwd = hash.toString(16);
			StringBuilder sbuffer = new StringBuilder(md5pwd);
			while (sbuffer.length() < 32) { // 40 for SHA-1
				sbuffer.insert(0, "0");
			}
			md5pwd = sbuffer.toString();
		}
		return md5pwd;
	}

	/**
	 * 邮箱校验判断有唯一[ @ ] 跟随唯一[ . ]
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public static Boolean checkEmail(String email) {
		Boolean result = false;

		if (email.indexOf('@') == -1) {
			return false;
		}
		if (email.indexOf('.') == -1) {
			return false;
		}
		if (email.indexOf('@') == email.lastIndexOf('@')) {
			result = true;
		}
		if (email.substring(email.indexOf('@'), email.length() - 1).indexOf('.') == email.substring(email.indexOf('@'), email.length() - 1)
		        .lastIndexOf('.')) {
			result = true;
		}
		return result;
	}
	
	/**
	 * 判断字符串长度是否大于等于指定值
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public static Boolean checkMoneLength(String param,int length) {
		Boolean result = false;
		if(param.length()>=length){
			result =  true;
		}
		return result;
	}
	/**
	 * 判断字符串长度是否小于等于指定值
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public  static Boolean checkLessLength(String param,int length) {
		Boolean result = false;
		if(param.length()<=length){
			result =  true;
		}
		return result;
	}
	/**
	 * 邮编为0-9  五为数字
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public  static Boolean checkZipcode(int zipcode) {
		Boolean result = false;
		if(zipcode>=10000&&zipcode<99999){
			result =  true;
		}
		return result;
	}
	/**
	 * 卡号为0-9 14-16位
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public  static Boolean checkAccount(String account) {
		Boolean result = false;
		if(account.length()>=14&&account.length()<=16){
			result =  true;
		}
		return result;
	}
	
	/**
	 * 格式化金额，保留小数点后00
	 * 
	 * @param BigDecimal
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public  static String formatPrice(BigDecimal price) {
		
		BigDecimal result =    price.multiply(new BigDecimal(100)).divide(new BigDecimal(100)).setScale(2);
		

		return String.valueOf(result);
	}
	
	/**
	 * Html编码
	 * 
	 * @param source
	 * @return
	 */
	public static String encodeHtml(String source) {
		if (source == null) {
			return "";
		}
		String html;
		StringBuilder buffer = new StringBuilder();
		for (int i = 0; i < source.length(); i++) {
			char c = source.charAt(i);
			switch (c) {
			case '<':
				buffer.append("&lt;");
				break;
			case '>':
				buffer.append("&gt;");
				break;
			case '&':
				buffer.append("&amp;");
				break;
			case '"':
				buffer.append("&quot;");
				break;
			case 10:
			case 13:
				break;
			default:
				buffer.append(c);
			}
		}
		html = buffer.toString();
		return html;
	}
	
	public static boolean isInteger(Object obj) {
		if (obj == null) {
			return false;
		}
		try {
			int parseInt = Integer.parseInt(obj.toString());
			log.debug("isInteger value = {}", parseInt);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			return false;
		}
		return true;
	}
}
