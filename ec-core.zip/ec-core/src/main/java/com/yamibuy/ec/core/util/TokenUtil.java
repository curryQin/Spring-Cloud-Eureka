package com.yamibuy.ec.core.util;

import java.net.URLDecoder;

import com.alibaba.fastjson.JSON;
import com.yamibuy.ec.core.client.CustomerInfoClient;
import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;
import com.yamibuy.ec.core.entity.BaseResponse;
import com.yamibuy.ec.core.entity.Token;
import com.yamibuy.ec.core.entity.User;

import lombok.extern.slf4j.Slf4j;

/**
 * Token处理工具类
 */
@Slf4j
public final class TokenUtil {
	
	private static CustomerInfoClient customerInfoClient;

	private static CustomerInfoClient getCustomerInfoClient() {
		if (null == customerInfoClient) {
			customerInfoClient = SpringfactoryUtils.getBean(CustomerInfoClient.class);
		}
		return customerInfoClient;
	}

	public static Token convert(String token) {
		if (token == null || token.length() == 0) {
			return new Token();
		}

		try {
			return JSON.parseObject(StringUtils.decode(URLDecoder.decode(token,"utf-8")), Token.class);
		} catch (Exception e) {
//			log.debug("TokenUtil convert Exception {}",e);
			throw new YamibuyException("Token is invalid , Please ReLogin",YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
		}
	}

	/**
	 * 根据token获取用户id.
	 * 
	 * @param token
	 * @return 用户id.
	 */
	public static Integer getUserId(String token) {
		Token convert = convert(token);
		String data = convert.getData();
		if ( null == data) {
			throw new YamibuyException("Token is invalid , Please ReLogin",
					YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
		}
		boolean numeric = org.apache.commons.lang.StringUtils.isNumeric(data);
		if (!numeric) {
			throw new YamibuyException("Token is invalid , Please ReLogin",
					YamibuyMessageCode.TOKEN_IS_INVALID.getCode());
		}
		return Integer.valueOf(data);
	}

	/**
	 * 根据token获取客户Id (redis cache)
	 * 
	 * @param token
	 * @return 临时token返回null
	 */
	public static Integer getCustomerId(String token) {
		Integer userId = null;
		Token convert = convert(token);
		if (convert.getIsLogin() == 1) {
			userId = Integer.valueOf(convert.getData());
		}
		return userId;
	}
	
	public static User getCustomerSimpleInfoByToken(String token) {
		Integer userId = getUserId(token);
		BaseResponse<User> response = null;
		try {
			log.debug("TokenUtil getCustomerSimpleInfoByToken user_id : {}",userId);
			response = getCustomerInfoClient().querySimpleInfoById(userId);
			log.debug("TokenUtil getCustomerSimpleInfoByToken Response : {}",JSON.toJSONString(response));
		} catch (Exception e) {
			log.error("TokenUtil getCustomerSimpleInfoByToken Failed",e);
			return null;
		}
		if (null == response || !YamibuyMessageCode.SUCCESS.getCode().equals(response.getMessageId())) {
			log.error("TokenUtil getCustomerSimpleInfoByToken Response error");
			return null;
		}
		return response.getBody();
	}
	
}
