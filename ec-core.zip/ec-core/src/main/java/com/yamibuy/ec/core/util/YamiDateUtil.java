package com.yamibuy.ec.core.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public final class YamiDateUtil {

	public static final String TIME_ZONE_STR = "America/Los_Angeles";

	/**
	 * 处理时区转化的方法
	 * 
	 * @param date 待转化的时间对象
	 * @param oldZone 原始时区
	 * @param newZone 目的时区
	 * @return Date 转化后的时间对象
	 */
	public static Date changeTimeZone(Date date, TimeZone oldZone, TimeZone newZone) {
		if (date != null) {
			int timeOffset = oldZone.getRawOffset() - newZone.getRawOffset();
			date.setTime(date.getTime() - timeOffset);
		}
		return date;
	}

	public static Long get_LA_Millisecond() {
		Calendar LA_calendar = Calendar.getInstance(TimeZone.getTimeZone(TIME_ZONE_STR));
		return LA_calendar.getTimeInMillis();
	}

	public static Long get_LA_Second() {
		Calendar LA_calendar = Calendar.getInstance(TimeZone.getTimeZone(TIME_ZONE_STR));
		return LA_calendar.getTimeInMillis() / 1000;
	}

	public static Calendar get_LA_Calendar() {
		return Calendar.getInstance(TimeZone.getTimeZone(TIME_ZONE_STR));
	}

	public static Date get_LA_Date() {
		Calendar LA_calendar = Calendar.getInstance(TimeZone.getTimeZone(TIME_ZONE_STR));
		return LA_calendar.getTime();
	}

	/**
	 * 获取当前UTC时间毫秒数
	 * 
	 * @return Long
	 */
	public static Long get_UTC_Millisecond() {
		return get_UTC_Millisecond(Calendar.getInstance());
	}

	/**
	 * 转换为UTC时间毫秒数
	 * 
	 * @return Long
	 */
	public static Long get_UTC_Millisecond(Calendar calendar) {
		return get_UTC_Calendar(calendar).getTimeInMillis();
	}

	/**
	 * 返回utc Calendar 时间对象
	 * 
	 * @return Calendar
	 */
	public static Calendar get_UTC_Calendar() {
		Calendar nowCalendar = Calendar.getInstance();
		return get_UTC_Calendar(nowCalendar);
	}

	/**
	 * 返回utc Calendar , LA时间对象
	 * 
	 * @return Calendar
	 */
	public static Calendar get_UTC_Calendar(Calendar calendar) {
		int ZERO_ZONE_OFFSET = calendar.get(Calendar.ZONE_OFFSET);
		int ZERO_DST_OFFSET = calendar.get(Calendar.DST_OFFSET);
		// 获取零时区(减去当前时区偏移量)
		calendar.add(Calendar.MILLISECOND, -(ZERO_ZONE_OFFSET + ZERO_DST_OFFSET));

		Calendar LA_calendar = Calendar.getInstance(TimeZone.getTimeZone(TIME_ZONE_STR));
		LA_calendar.setTimeInMillis(calendar.getTimeInMillis());
		int LA_ZONE_OFFSET = LA_calendar.get(Calendar.ZONE_OFFSET);
		int LA_DST_OFFSET = LA_calendar.get(Calendar.DST_OFFSET);
		// calendar 转换为 LA时间(零时区加当前时区偏移量)
		calendar.add(Calendar.MILLISECOND, LA_ZONE_OFFSET + LA_DST_OFFSET);
		return calendar;
	}

	/**
	 * 获取此刻utc时间的方法
	 * 
	 * @return Date 此刻UTC时间
	 */
	public static Date get_UTC_Date() {
		Calendar UTC_calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		Date time = UTC_calendar.getTime();
		Date date = changeTimeZone(time, TimeZone.getDefault(), TimeZone.getTimeZone("GMT"));
		return date;
	}

	/**
	 * 获取utc, date 对象
	 * 
	 * @param calendar
	 * @return Date
	 */
	public static Date get_UTC_Date(Calendar calendar) {
		return changeTimeZone(new Date(), TimeZone.getDefault(), TimeZone.getTimeZone("GMT"));
	}

	/**
	 * 转换为Los_Angeles时区字符串.
	 * 
	 * @param time
	 * @param df
	 * @return
	 */
	public static String convertTimeZone(int time, SimpleDateFormat df) {
		if (time <= 0) {
			return "N/A";
		}
		Long timeLong = time * 1000L;
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timeLong);
		Date date = YamiDateUtil.get_UTC_Calendar(cal).getTime();
		return df.format(date);
	}

	/**
	 * 将UTC时间转化为本地时区时间的方法
	 * 
	 * @param date UTC时间对象
	 * @return Date 转化后的当地时间
	 */
	public static Date getCurrentTimeZoneDate(Date date) {
		return changeTimeZone(date, TimeZone.getTimeZone("GMT"), TimeZone.getDefault());
	}

}
