package com.yamibuy.ec.core.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.StringTokenizer;

import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;

/**
 * 
 * @author Kevin.Hu
 *
 */
public final class YamiPropertiesUtil {

	private static YamiPropertiesUtil yamiPropertiesUtil = SingleLite.INSTANCE;

	private static class SingleLite {
		static final YamiPropertiesUtil INSTANCE = new YamiPropertiesUtil();
	}

	public static YamiPropertiesUtil getInstance() {
		return yamiPropertiesUtil;
	}

	public static Object getValue(String fileName, String key) {
		Properties properties = yamiPropertiesUtil.load(fileName);
		return properties.get(key);
	}

	public Properties load(final String propertiesFile) {
		Properties properties = null;

		String templatePath = Generator.getInstance().getPropertiesPath();
		try {
			if (templatePath != null) {
				properties = loadFromTemplatePath(propertiesFile);
			} else {
				properties = loadFromClassPath(propertiesFile);
			}
		} catch (RuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw new YamibuyException(e, YamibuyMessageCode.SYSTEMERROR.getCode());
		}
		return properties;
	}

	private Properties loadFromTemplatePath(final String propertiesFile){
		Properties properties = new Properties();
		String templatePath = Generator.getInstance().getTemplatePath();

		StringTokenizer st = new StringTokenizer(templatePath, ",");
		while (st.hasMoreTokens()) {
			String templateDir = st.nextToken();
			String fullPath = propertiesFile;
			if (!fullPath.startsWith(templateDir)) {
				fullPath = templateDir + "/" + propertiesFile;
			}
			try (InputStream stream = new FileInputStream(fullPath)){
				properties.load(stream);
				break;
			} catch (IOException e) {
				throw new YamibuyException(e, YamibuyMessageCode.SYSTEMERROR.getCode());
			}
		}
		return properties;
	}

	/**
	 * Load a properties file from the classpath
	 *
	 * @param propertiesName the properties file to load.
	 * @return a properties instance loaded with the properties from the file. 
	 * 		   If no file can be found it returns an empty instance.
	 * @throws Exception
	 */
	private Properties loadFromClassPath(final String propertiesName) {
		Properties properties = new Properties();
		ClassLoader classLoader = this.getClass().getClassLoader();

		String propertiesFile = propertiesName.startsWith("$generator") ? 
				propertiesName.substring("$generator.templatePath/".length()) : propertiesName;
		try (InputStream inputStream = classLoader.getResourceAsStream(propertiesFile)) {
			properties.load(inputStream);
		} catch (IOException e) {
			throw new YamibuyException(e, YamibuyMessageCode.SYSTEMERROR.getCode());
		}

		return properties;
	}

	static class Generator {
		private static Generator instance = new Generator();

		public static final String TEMPLATE_PATH = "template.path";
		public static final String PROPERTIES_PATH = "classpath:";

		private Properties props = new Properties();

		public static Generator getInstance() {
			return instance;
		}

		public String getTemplatePath() {
			return props.getProperty(TEMPLATE_PATH);
		}

		public String getPropertiesPath() {
			return props.getProperty(PROPERTIES_PATH);
		}
	}
}
