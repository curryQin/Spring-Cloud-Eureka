package com.yamibuy.ec.core.util;

import java.math.BigDecimal;
import java.util.List;

import com.yamibuy.ec.core.common.YamibuyException;
import com.yamibuy.ec.core.common.YamibuyMessageCode;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <br>
 * <b>功能：</b>Check<br>
 * <b>作者：</b>www.yamibuy.com<br>
 * <b>日期：</b> May 1, 2016 <br>
 * <b>版权所有：</b>版权所有(C) 2016，www.yamibuy.com<br>
 */
@Slf4j
public final class YamiStringUtils {
	
	/**
	 * Function : Verify the object whether is null or ""
	 * 
	 * @author Harry He
	 * @param obj Object
	 * @return boolean
	 */
	public static boolean isBlank(Object obj) {
		if (obj == null) {
			return true;
		}
		return StringUtils.isBlank(String.valueOf(obj));
	}

	public static boolean isBlank(Object... objects) {
		if (objects == null) {
			return true;
		}
		for (Object obj : objects) {
			if (isBlank(obj)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isEmpty(Object obj) {
		if (obj == null || String.valueOf(obj).trim().length() < 1) {
			return true;
		}
		return false;
	}

	public static boolean isInteger(Object obj) {
		if (obj == null) {
			return false;
		}
		try {
			int parseInt = Integer.parseInt(obj.toString());
			log.debug("isInteger value = {}", parseInt);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			return false;
		}
		return true;
	}

	public static boolean isLong(Object obj) {
		if (obj == null) {
			return false;
		}
		try {
			Long.parseLong(obj.toString());
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			return false;
		}
		return true;
	}

	/**
	 * <pre>
	 * Function : Verify the BigDecimal whether is null or "" , 
	 * if yes Response defaultDecimal , id no Response itself
	 * </pre>
	 * 
	 * @author Harry He
	 * @param bigDecimal BigDecimal
	 * @param defaultDecimal Default Value
	 * @return BigDecimal
	 */
	public static BigDecimal checkBigDecimal(BigDecimal bigDecimal, BigDecimal defaultDecimal) {
		if (isEmpty(bigDecimal)) {
			return defaultDecimal;
		} else {
			if (bigDecimal.compareTo(BigDecimal.ZERO) < 0 || bigDecimal.compareTo(BigDecimal.valueOf(99999999.99)) > 0) {
				throw new YamibuyException("BigDecimal value have Error", 
						YamibuyMessageCode.WRONGVALUE_BIGDECIMAL.getCode(), bigDecimal.toString());
			} else {
				return bigDecimal;
			}
		}
	}

	/**
	 * <pre>
	 * Function : Verify the Char whether is null or "" and whether is Active status, 
	 * if yes Response active Value, id no Response deactive Value
	 * </pre>
	 * 
	 * @author Harry He
	 * @param string BigDecimal
	 * @param active Default Active Value
	 * @param deactive Default DeActive Value
	 * @return String
	 */
	public static String checkChar(String string, String active, String deactive) {
		return isEmpty(string) && active.equalsIgnoreCase(string) ? active : deactive;
	}

	/**
	 * Function : Verify the String whether is null or "" , if yes Response defaultString , id no Response itself
	 * 
	 * @author Harry He
	 * @param string String
	 * @param defaultString Default Value
	 * @return String
	 */
	public static String checkString(String string, String defaultString) {
		if (isEmpty(string)) {
			return defaultString;
		} else {
			return string;
		}
	}

	/**
	 * Function : Verify the Integer whether is null or "" , if yes Response defaultInteger , id no Response itself
	 * 
	 * @author Harry He
	 * @param integer String
	 * @param defaultInteger Default Value
	 * @return Integer
	 */
	public static Integer checkInteger(Integer integer, Integer defaultInteger) {
		return StringUtils.checkInteger(integer, defaultInteger);
	}

	public static String listToString(List<String> list) {
		return StringUtils.listToString(list);
	}

	/**
	 * 邮编为0-9 五为数字
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public static Boolean checkZipcode(String zipcode) {
		String zipCodePattern = "^[0-9]{5}$";
		return zipcode.matches(zipCodePattern);
	}

	/**
	 * 邮箱校验判断有唯一[ @ ] 跟随唯一[ . ]
	 * 
	 * @param String
	 * @return Boolean true:通过验证 false:未通过验证
	 */
	public static Boolean checkEmail(String email) {
		Boolean result = false;
		int dotIndex = email.indexOf('.');
		int emailIndex = email.indexOf('@');
		if (emailIndex == -1 || dotIndex == -1) {
			return false;
		}
		if (emailIndex == email.lastIndexOf('@')) {
			result = true;
		}
		if (email.substring(emailIndex, email.length() - 1).indexOf('.') == email.substring(emailIndex, email.length() - 1)
				.lastIndexOf('.')) {
			result = true;
		}
		return result;
	}

	/**
	 * 
	 * @Title : filterChinese
	 * @Type : FilterStr
	 * @Description : 过滤出中文
	 * @param chin
	 * @return
	 */
	public static String filterChinese(String chin) {
		return chin.replaceAll("[^(\\u4e00-\\u9fa5)]", "");
	}
}
